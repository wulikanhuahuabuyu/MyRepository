package com.RegExp.demo;

import com.RegExp.demo.entity.Bns_Pm_Operation;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class BarcodeRestore {

    /**
     * 查机编
     */
    @Test
    public void barcodeRestoreTest() {
        /*
         流水码：&barcodes=
         资产码：&numbers=
         随机码：&randomBarcodes=
         订单编码：&orderCodes=
         */
//        String content = "&barcodes=B00UV300000BFN3H0099&barcodes=CE0JPP0000007N160346";
        String content = "&randomBarcodes=BB0A200AE00BEL4VMWLQ";

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url("https://hw.haier.net/mom-gw-t/im-mes/barcode/queryBarcodeByCode?lang=zh_CN&page=1&rows=20&size=20" + content)
                .method("GET", null)
                .addHeader("accept", "*/*")
                .addHeader("accept-language", "zh-CN,zh;q=0.9")
                .addHeader("authorization", "Bearer eyJ0eXAiOiJqd3QiLCJhbGciOiJSUzI1NiIsImtpZCI6Imk4NW9vdCJ9.eyJzdWIiOiJBMDA0MTEwMiIsImF1ZCI6ImxvZ2luIiwibmJmIjoxNzQzNTgzODA0LCJURVJNSU5BTC1UWVBFIjoicGMiLCJBQ0NPVU5ULVNPVVJDRS1UWVBFIjoiQSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLVJPTEUtTkFNRSI6IiVFNyU5NCU5RiVFNCVCQSVBNy0lRTUlODYlQjAlRTclQUUlQjEtJUU1JTg2JTg1JUU4JTgzJTg2JUU1JTkwJUI4JUU5JTk5JTg0JUU3JThGJUFEJUU3JUJBJUJGJUU5JTk1JUJGLSVFNyU5NCU5RiVFNCVCQSVBNyVFNiU4RSU5MiVFNCVCQSVBNyIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJTQy1CWC1ORFhGQlhDLVNDUEMiLCJqdGkiOiJjM2FkZjU3Yi03OGQxLTQ2YTktOGJjMi1hYTIwYTFmNmE4YTUiLCJpYXQiOjE3NDM1ODM4MDQsImV4cCI6MTc0NDE4ODYwNH0.bNb7czt11wJ3GAE6I4qX4_aRDh6fokObP-3rSsRfyxfh3sy9tVkSCyrNO8E5pFu_DpqCYofd3HJEn87WKtjhg-Usro1dN3l5g5r5gXzy_ZutjTMiYrPLzUV-qQqpKGxpgHEnXkUntiO6yn767UiIOn_eJ3aRYyyqTbPhKH_hVF_TPOuXjvrn-dQq64KIzGtF1oMDfBR9ufVe-E_pHxPdcSkUWwA2qxYcLdHKmwU-zy1mp8HGSHm9-CXbLub2cvO1zQ2nLeH5Js3dENeii6H7PdddFczTxzttyvXiafalbXJsgGtXEa_24nQ4Dg2T4X3SGJRpd8FzajMNFn5lEp9-6A")
                .addHeader("cookie", "gr_user_id=0e24675e-9de9-4d8c-b8f8-064d651a99f6; ae2eee21ce6f705e_gr_last_sent_cs1=A0041102; hwork_machine_id=50fe7b23-c3cf-4d36-9c3c-794ccc38444c; INGRESSCOOKIE=4dbef18efc17a53bc72f7257066cdc23; ae2eee21ce6f705e_gr_session_id=721aef92-9135-492f-93da-64df843c2423; ae2eee21ce6f705e_gr_last_sent_sid_with_cs1=721aef92-9135-492f-93da-64df843c2423; ae2eee21ce6f705e_gr_session_id_sent_vst=721aef92-9135-492f-93da-64df843c2423; workbenchToken=eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJURVJNSU5BTC1UWVBFIjoicGMiLCJVU0VSLUVNQUlMIjoiaGsueGlhb3BwQGhhaWVyLmNvbSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLU5BTUUiOiIlRTglODIlOTYlRTglOTAlOEQlRTglOTAlOEQiLCJVU0VSLVBIT05FIjoiMTUxOTQyNTU5ODciLCJVU0VSLVJPTEUtTkFNRSI6IiVFNyU5NCU5RiVFNCVCQSVBNy0lRTclQTklQkElRTglQjAlODMtJUU0JUJFJTlCJUU1JUJBJTk0JUU5JTkzJUJFJUU3JTk0JTlGJUU0JUJBJUE3JUU3JUFFJUExJUU3JTkwJTg2JUU0JUJBJUJBJUU1JTkxJTk4LSVFNSU4OSU4RCVFNSVCNyVBNSVFNSVCQSU4RiVFNyVBRSVBMSVFNyU5MCU4NiIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJTQy1LRC1HWUxTQ0dMUlktUUdYR0wiLCJpYXQiOjE3MjEyODY2OTksImV4cCI6MTcyMTg5MTQ5OX0.H9dj72_K8ieUEi01e2mMiO05ifDi5dFn8Tqk_lXwukM; hwork_token=eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJURVJNSU5BTC1UWVBFIjoicGMiLCJVU0VSLUVNQUlMIjoiaGsueGlhb3BwQGhhaWVyLmNvbSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLU5BTUUiOiIlRTglODIlOTYlRTglOTAlOEQlRTglOTAlOEQiLCJVU0VSLVBIT05FIjoiMTUxOTQyNTU5ODciLCJVU0VSLVJPTEUtTkFNRSI6IiVFNyU5NCU5RiVFNCVCQSVBNy0lRTclQTklQkElRTglQjAlODMtJUU0JUJFJTlCJUU1JUJBJTk0JUU5JTkzJUJFJUU3JTk0JTlGJUU0JUJBJUE3JUU3JUFFJUExJUU3JTkwJTg2JUU0JUJBJUJBJUU1JTkxJTk4LSVFNSU4OSU4RCVFNSVCNyVBNSVFNSVCQSU4RiVFNyVBRSVBMSVFNyU5MCU4NiIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJTQy1LRC1HWUxTQ0dMUlktUUdYR0wiLCJpYXQiOjE3MjEyODY2OTksImV4cCI6MTcyMTg5MTQ5OX0.H9dj72_K8ieUEi01e2mMiO05ifDi5dFn8Tqk_lXwukM; hwork_token_prod=eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJURVJNSU5BTC1UWVBFIjoicGMiLCJVU0VSLUVNQUlMIjoiaGsueGlhb3BwQGhhaWVyLmNvbSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLU5BTUUiOiIlRTglODIlOTYlRTglOTAlOEQlRTglOTAlOEQiLCJVU0VSLVBIT05FIjoiMTUxOTQyNTU5ODciLCJVU0VSLVJPTEUtTkFNRSI6IiVFNyU5NCU5RiVFNCVCQSVBNy0lRTclQTklQkElRTglQjAlODMtJUU0JUJFJTlCJUU1JUJBJTk0JUU5JTkzJUJFJUU3JTk0JTlGJUU0JUJBJUE3JUU3JUFFJUExJUU3JTkwJTg2JUU0JUJBJUJBJUU1JTkxJTk4LSVFNSU4OSU4RCVFNSVCNyVBNSVFNSVCQSU4RiVFNyVBRSVBMSVFNyU5MCU4NiIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJTQy1LRC1HWUxTQ0dMUlktUUdYR0wiLCJpYXQiOjE3MjEyODY2OTksImV4cCI6MTcyMTg5MTQ5OX0.H9dj72_K8ieUEi01e2mMiO05ifDi5dFn8Tqk_lXwukM; refreshToken=PNReasTVDVKUDEi3Ra/0B99Hy7NNG81WkdhDOtmc9IjwJ6rJqLRp4Zg9wFg5OPf9; hwork_refresh_token=PNReasTVDVKUDEi3Ra/0B99Hy7NNG81WkdhDOtmc9IjwJ6rJqLRp4Zg9wFg5OPf9; hwork_refresh_token_prod=PNReasTVDVKUDEi3Ra/0B99Hy7NNG81WkdhDOtmc9IjwJ6rJqLRp4Zg9wFg5OPf9; ae2eee21ce6f705e_gr_cs1=A0041102; sessionCookie=53e1442e-5b88-4b1b-b907-a09e7c167360")
                .addHeader("cosmo-env-sitecode", "1001")
                .addHeader("priority", "u=1, i")
                .addHeader("referer", "https://hw.haier.net/portal/im/BarcodeRestore")
                .addHeader("sec-ch-ua", "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"")
                .addHeader("sec-ch-ua-mobile", "?0")
                .addHeader("sec-ch-ua-platform", "\"Windows\"")
                .addHeader("sec-fetch-dest", "empty")
                .addHeader("sec-fetch-mode", "cors")
                .addHeader("sec-fetch-site", "same-origin")
                .addHeader("sitecode", "1001")
                .addHeader("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
                .addHeader("x-mom-authorization", "eyJ0eXBlIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiJkNGZjMWUzNDQ3ZjI0YjAxODE5ZTNjMjYyMThlOWQ2YiIsImlhdCI6MTcyMTI4Njk4OCwiZXhwIjoxNzIxMzA0OTg4LCJVU0VSX0tFWSI6IntcInVzZXJJZFwiOlwiZDRmYzFlMzQ0N2YyNGIwMTgxOWUzYzI2MjE4ZTlkNmJcIixcImxvZ2luTmFtZVwiOlwiQTAwNDExMDJcIixcInVzZXJOYW1lXCI6XCLogpbokI3okI1cIixcImVtYWlsXCI6bnVsbCxcInBob25lXCI6bnVsbCxcIm1vYmlsZVwiOm51bGwsXCJhdmF0YXJVcmxcIjpudWxsfSJ9.SaXWMCw0lWltxUI8zxEeHVsT4cd1IBFF3XGP66weZiY")
                .addHeader("x-requested-with", "XMLHttpRequest")
                .build();


        Response response;
        try {
            response = client.newCall(request).execute();
            String body_json = response.body().string();
//            System.err.println(body_json);

            JSONObject jsonObject = new JSONObject(body_json);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            Bns_Pm_Operation bnsPmOperation = new Bns_Pm_Operation();
            JSONObject jsonObject1;

            // 写入文件路径
            String path = "D:\\barcodeRestore.txt";
            //清空数据重新写入
            if (new File(path).exists()) {
                new File(path).delete();
            }
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream(path, true)));

            for (int i = 0; i < jsonArray.length(); i++) {
                jsonObject1 = jsonArray.getJSONObject(i);
                System.err.println(
//                        jsonObject1.getString("assetNumber") + "\t" +
                                jsonObject1.getString("workuserBarcode") + "\t" +
                                jsonObject1.getString("workuserRandombarcode") + "\t" +
                                jsonObject1.getString("workuserMordercode") + "\t" +
                                jsonObject1.getString("workOperationoutmainitemcode") + "\t" +
                                jsonObject1.getString("workuserRightmostitemname") + "\t" +
                                jsonObject1.getString("cipher")
                );

                out.write(
                        jsonObject1.getString("workuserMordercode") + "\t" +
                                jsonObject1.getString("workOperationoutmainitemcode") + "\t" +
                                jsonObject1.getString("workuserRightmostitemname") + "\t" +
                                jsonObject1.getString("workuserBarcode") + "\t" +
//                                jsonObject1.getString("workuserRandombarcode") + "\t" +
//                                jsonObject1.getString("assetNumber") + "\r\n"
//                                jsonObject1.getString("workuserBarcodeprint") + "\t" +
                                jsonObject1.getString("cipher") + "\r\n"
//                                jsonObject1.getString("siteCode") + "\t" +
//                                jsonObject1.getString("cipher") + "\r\n"
                );
            }
            out.close();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

    }


    /**
     * 批量生成INSERT语句用于批量还原已备份条码
     */
    @Test
    public void BarcodeRestoreBatchInsert() {
         /*
         流水码：&barcodes=
         资产码：&numbers=
         随机码：&randomBarcodes=
         订单编码：&orderCodes=
         */
        String content = "&randomBarcodes=B30K9001K00BWP2QJ5LC&randomBarcodes=B30K9001K00BWP2PQEX0&randomBarcodes=B30K9001K00BWP2PTCZQ&randomBarcodes=B30K9001K00BWP2QHY7L&randomBarcodes=B30K9001K00BWP2QSJ9E&randomBarcodes=B30K9001K00BWP2TTWLM&randomBarcodes=B30K9001K00BWP2PWPE8&randomBarcodes=B30K9001K00BWP2QWUQ8";

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url("https://hwork.haier.net/mom-gw/im-mes/barcode/queryBarcodeByCode?lang=zh_CN" + content)
                .method("GET", null)
                .addHeader("authority", "hwork.haier.net")
                .addHeader("accept", "*/*")
                .addHeader("accept-language", "zh-CN,zh;q=0.9")
                .addHeader("authorization", "eyJ0eXBlIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJzdWIiOiI0MmI1N2MxYTRiMzA0YWRiYTk2NmNiNDM3OTZmOTdkMSIsImlhdCI6MTY5MTc0MDE5MywiZXhwIjoxNjkxNzU4MTkzLCJVU0VSX0tFWSI6IntcInVzZXJJZFwiOlwiNDJiNTdjMWE0YjMwNGFkYmE5NjZjYjQzNzk2Zjk3ZDFcIixcImxvZ2luTmFtZVwiOlwiQTAwNDExMDJcIixcInVzZXJOYW1lXCI6XCLogpbokI3okI1cIixcImVtYWlsXCI6bnVsbCxcInBob25lXCI6bnVsbCxcIm1vYmlsZVwiOm51bGwsXCJhdmF0YXJVcmxcIjpudWxsfSJ9.RU7ybNb9Td-k7WxvkHqXLct4AgZfOWnwge0dAtNgHpw")
                .addHeader("cookie", "INGRESSCOOKIE=0f31f94d81d584959318a88cf773acc2; gr_user_id=a0797a78-426f-4274-889c-21e1f8ced077; ae2eee21ce6f705e_gr_last_sent_cs1=A0041102; hwork_machine_id=e5b7c4c5-2f62-431b-a41c-ebdba99587ae; ae2eee21ce6f705e_gr_session_id=b88f548e-7634-4f6e-b89b-af571170152e; INGRESSCOOKIE=efa294f320d9a16e411959c09461ddd0; ae2eee21ce6f705e_gr_session_id_sent_vst=b88f548e-7634-4f6e-b89b-af571170152e; ae2eee21ce6f705e_gr_last_sent_sid_with_cs1=b88f548e-7634-4f6e-b89b-af571170152e; sessionCookie=6d146e41-8990-4ddf-a222-c2a1c8a18dc0; workbenchToken=eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJURVJNSU5BTC1UWVBFIjoicGMiLCJVU0VSLUVNQUlMIjoiaGsueGlhb3BwQGhhaWVyLmNvbSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLU5BTUUiOiIlRTglODIlOTYlRTglOTAlOEQlRTglOTAlOEQiLCJVU0VSLVBIT05FIjoiMTUxOTQyNTU5ODciLCJVU0VSLVJPTEUtTkFNRSI6IiVFOSU4MCU5QSVFNyU5NCVBOCVFOCVBNyU5MiVFOCU4OSVCMiIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJ6eHB0cnkiLCJpYXQiOjE3MTMyNDg5OTUsImV4cCI6MTcxMzg1Mzc5NX0.xA9h_hhugfo4hT1qjl_5XEmNsyDyy39Fd9XWUlJqzJ4; hwork_token=eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJURVJNSU5BTC1UWVBFIjoicGMiLCJVU0VSLUVNQUlMIjoiaGsueGlhb3BwQGhhaWVyLmNvbSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLU5BTUUiOiIlRTglODIlOTYlRTglOTAlOEQlRTglOTAlOEQiLCJVU0VSLVBIT05FIjoiMTUxOTQyNTU5ODciLCJVU0VSLVJPTEUtTkFNRSI6IiVFOSU4MCU5QSVFNyU5NCVBOCVFOCVBNyU5MiVFOCU4OSVCMiIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJ6eHB0cnkiLCJpYXQiOjE3MTMyNDg5OTUsImV4cCI6MTcxMzg1Mzc5NX0.xA9h_hhugfo4hT1qjl_5XEmNsyDyy39Fd9XWUlJqzJ4; hwork_token_prod=eyJ0eXAiOiJqd3QiLCJhbGciOiJIUzI1NiJ9.eyJURVJNSU5BTC1UWVBFIjoicGMiLCJVU0VSLUVNQUlMIjoiaGsueGlhb3BwQGhhaWVyLmNvbSIsImlzcyI6Imh3b3JrLXByb2QiLCJVU0VSLU5BTUUiOiIlRTglODIlOTYlRTglOTAlOEQlRTglOTAlOEQiLCJVU0VSLVBIT05FIjoiMTUxOTQyNTU5ODciLCJVU0VSLVJPTEUtTkFNRSI6IiVFOSU4MCU5QSVFNyU5NCVBOCVFOCVBNyU5MiVFOCU4OSVCMiIsIlVTRVItV0hPTEUtTkVUIjowLCJVU0VSIjoiQTAwNDExMDIiLCJVU0VSLVJPTEUiOiJ6eHB0cnkiLCJpYXQiOjE3MTMyNDg5OTUsImV4cCI6MTcxMzg1Mzc5NX0.xA9h_hhugfo4hT1qjl_5XEmNsyDyy39Fd9XWUlJqzJ4; refreshToken=uCgjFNNbxalEjRtIim3QTznzdUAW6v6R/6g4gJv3HpIcCpU3pKZJ6+p1oqBnLumi; hwork_refresh_token=uCgjFNNbxalEjRtIim3QTznzdUAW6v6R/6g4gJv3HpIcCpU3pKZJ6+p1oqBnLumi; hwork_refresh_token_prod=uCgjFNNbxalEjRtIim3QTznzdUAW6v6R/6g4gJv3HpIcCpU3pKZJ6+p1oqBnLumi; ae2eee21ce6f705e_gr_cs1=A0041102")
                .addHeader("cosmo-env-sitecode", "1025")
                .addHeader("referer", "https://hw.haier.net/portal/im/BarcodeRestore")
                .addHeader("sec-ch-ua", "\"Not/A)Brand\";v=\"99\", \"Google Chrome\";v=\"115\", \"Chromium\";v=\"115\"")
                .addHeader("sec-ch-ua-mobile", "?0")
                .addHeader("sec-ch-ua-platform", "\"Windows\"")
                .addHeader("sec-fetch-dest", "empty")
                .addHeader("sec-fetch-mode", "cors")
                .addHeader("sec-fetch-site", "same-origin")
                .addHeader("sitecode", "1025")
                .addHeader("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36")
                .addHeader("x-requested-with", "XMLHttpRequest")
                .build();

        Response response;
        try {
            response = client.newCall(request).execute();
            String body_json = response.body().string();

            JSONObject jsonObject = new JSONObject(body_json);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            Bns_Pm_Operation bnsPmOperation = new Bns_Pm_Operation();
            JSONObject jsonObject1 = null;

            // 写入文件路径
            String path = "D:\\barcodeRestore.txt";
            //清空数据重新写入
            if (new File(path).exists()) {
                new File(path).delete();
            }
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream(path, true)));

            String str = "INSERT INTO bns_pm_operation" +
                    " (" +
                    "ID,Work_OrderCode,Work_Code,Work_OperationOutMainItemCode,WorkUser_RightMostItemName,Work_OperationOutMainItemQty,Work_OperationMainResCode,Work_OperationProductionStartT,Work_OperationProductionEndTim,Work_OperationProductionTime,Work_Status,WorkUser_SaleVersion,WorkUser_BarCodePrint,WorkUser_PlanHour,WorkUser_Planday,WorkUser_MOrderCode,WorkUser_ItemType,WorkUser_BarCode,WorkUser_frontBarCode,WorkUser_DayOrderCode,WorkUser_Factory,WorkUser_OrderType,WorkUser_Unit,WorkUser_LeftOrder,WorkUser_RightOrder,WorkUser_LeftmostOrder,WorkUser_RightmostOrder,WorkUser_LineName,WorkUser_LineCode,Work_ResultStartTime,Work_ResultEndTime,WorkUser_IsFTT,TimeSeriesFlag,InspectResult,WorkUser_CustomerCode,WorkUser_CustomerInfo,WorkUser_ContacterPhone,WorkUser_ContacterName,WorkUser_ScheduleDate,WorkUser_TradeCode,WorkUser_TradeName,WorkUser_ChannelCode,WorkUser_ChannelName,JFLFlag,CPFlag,FLFlag,DailyWorkFlag,T_WMS_1,LineSideFlag,CUST_ORDER_CODE,BANK,ImageTemp,WareHouseStatus,Displndex,Remark,Create_By,Create_Date,Last_Update_By,Last_Update_Date,Active,Date_Syn_Flage,checkcode,oid,site_id,site_code,WorkUser_RandomBarCode,Export_Code,Energy_URL,encryption_barcode,self_control_barcode,is_cp,geAndhide,Asset_Number,WiFi_Code,Cipher,Enterprise_Code,Enterprise_Id,WorkUser_PressBarCode" +
                    ") VALUES (";

            int array_length = 0;
            for (int i = 0; i < jsonArray.length(); i++) {
                jsonObject1 = jsonArray.getJSONObject(i);
                array_length = jsonObject1.getString("id").split("_").length;

                out.write(
                        str
                                + "'" + jsonObject1.getString("id").split("_")[array_length-1] + "',"
                                + "'" + jsonObject1.getString("workOrdercode") + "',"
                                + "'" + jsonObject1.getString("workCode") + "',"
                                + "'" + jsonObject1.getString("workOperationoutmainitemcode") + "',"
                                + "'" + jsonObject1.getString("workuserRightmostitemname") + "',"
                                + "'" + jsonObject1.getString("workOperationoutmainitemqty") + "',"
                                + "'" + jsonObject1.getString("workOperationmainrescode") + "',"
                                + "'" + jsonObject1.getString("workOperationproductionstartt") + "',"
                                + "'" + jsonObject1.getString("workOperationproductionendtim") + "',"
                                + "'0.000',"//Work_OperationProductionTime
                                + "'" + jsonObject1.getString("workStatus") + "',"
                                + "'" + jsonObject1.getString("workuserSaleversion") + "',"
                                + "'" + jsonObject1.getString("workuserBarcodeprint") + "',"
                                + "'" + jsonObject1.getString("workuserPlanhour") + "',"
                                + "'" + jsonObject1.getString("workuserPlanday") + "',"
                                + "'" + jsonObject1.getString("workuserMordercode") + "',"
                                + "'" + jsonObject1.getString("workuserItemtype") + "',"
                                + "'" + jsonObject1.getString("workuserBarcode") + "',"
                                + "'" + jsonObject1.getString("workuserFrontbarcode") + "',"
                                + "'" + jsonObject1.getString("workuserDayordercode") + "',"
                                + "'" + jsonObject1.getString("workuserFactory") + "',"
                                + "'" + jsonObject1.getString("workuserOrdertype") + "',"
                                + "'" + jsonObject1.getString("workuserUnit") + "',"
                                + "'" + jsonObject1.getString("workuserLeftorder") + "',"
                                + "'" + jsonObject1.getString("workuserRightorder") + "',"
                                + "'" + jsonObject1.getString("workuserLeftmostorder") + "',"
                                + "'" + jsonObject1.getString("workuserRightmostorder") + "',"
                                + "'" + jsonObject1.getString("workuserLinename") + "',"
                                + "'" + jsonObject1.getString("workuserLinecode") + "',"
                                + "NULL,"// Work_ResultStartTime
                                + "NULL,"// Work_ResultEndTime
                                + "'0',"//WorkUser_IsFTT
                                + "'0',"//TimeSeriesFlag
                                + "'0',"//InspectResult
                                + "'" + jsonObject1.getString("workuserCustomercode") + "',"
                                + "'" + jsonObject1.getString("workuserCustomerinfo") + "',"
                                + "'" + jsonObject1.getString("workuserContacterphone") + "',"
                                + "'" + jsonObject1.getString("workuserContactername") + "',"
                                + "null,"// WorkUser_ScheduleDate
                                + "'" + jsonObject1.getString("workuserTradecode") + "',"
                                + "'" + jsonObject1.getString("workuserTradename") + "',"
                                + "'" + jsonObject1.getString("workuserChannelcode") + "',"
                                + "'" + jsonObject1.getString("workuserChannelname") + "',"
                                + "'" + jsonObject1.getString("jflflag") + "',"
                                + "'" + jsonObject1.getString("cpflag") + "',"
                                + "'" + jsonObject1.getString("flflag") + "',"
                                + "'" + jsonObject1.getString("dailyWorkFlag") + "',"
                                + "'" + jsonObject1.getString("twms1") + "',"
                                + "'" + jsonObject1.getString("lineSideFlag") + "',"
                                + "'" + jsonObject1.getString("custOrderCode") + "',"
                                + "'" + jsonObject1.getString("bank") + "',"
                                + "'" + jsonObject1.getString("imageTemp") + "',"
                                + "'1',"//WareHouseStatus
                                + "'0',"//Displndex
                                + "'" + jsonObject1.getString("remark") + "',"
                                + "'" + jsonObject1.getString("createBy") + "',"
                                + "'" + jsonObject1.getString("createDate") + "',"
                                + "'" + jsonObject1.getString("lastUpdateBy") + "',"
                                + "'" + jsonObject1.getString("lastUpdateDate") + "',"
                                + "'0',"//Active
                                + "'0',"//Date_Syn_Flage
                                + "'" + jsonObject1.getString("checkcode") + "',"
                                + "'" + jsonObject1.getString("oid") + "',"
                                + "'" + jsonObject1.getString("siteId") + "',"
                                + "'" + jsonObject1.getString("siteCode") + "',"
                                + "'" + jsonObject1.getString("workuserRandombarcode") + "',"
                                + "'" + jsonObject1.getString("exportCode") + "',"
                                + "'" + jsonObject1.getString("energyUrl") + "',"
                                + "'" + jsonObject1.getString("encryptionBarcode") + "',"
                                + "'" + jsonObject1.getString("selfControlBarcode") + "',"
                                + "'" + jsonObject1.getString("isCp") + "',"
                                + "'" + jsonObject1.getString("geAndhide") + "',"
                                + "'" + jsonObject1.getString("assetNumber") + "',"
                                + "'" + jsonObject1.getString("wifiCode") + "',"
                                + "'" + jsonObject1.getString("cipher") + "',"
                                + "'" + jsonObject1.getString("enterpriseCode") + "',"
                                + "'" + jsonObject1.getString("enterpriseId") + "',"
                                + "'" + jsonObject1.getString("workuserPressbarcode") + "');\n"
                );
            }
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

@Test public void test01() {
        String str = "6901018080050";
    System.err.println(str.substring(7,12));

    }



}
