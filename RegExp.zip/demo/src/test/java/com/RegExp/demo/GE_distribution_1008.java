package com.RegExp.demo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@SpringBootTest
@RunWith(SpringRunner.class)
public class GE_distribution_1008 {

    @Test
    public void generateZZBCPCode () {

        String prodCode = "0020811263AY";// 物料号 = 半成品专用号
        String line_code = "TD2";//线体编码
        String EST = "2024-04-07 00:00:00";//订单计划日期

        StringBuffer reStr = new StringBuffer("");
        //物料号 = 半成品专用号
        reStr.append(prodCode);
        //分隔符号
        reStr.append("#");
        //工厂编码
//		reStr.append(factoryNo);
        //线体编码
        reStr.append(line_code);
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = df.parse(EST);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.err.println(date);
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        String y = c.get(Calendar.YEAR)+"";
        int m = (c.get(Calendar.MONTH)+1);
        int d = c.get(Calendar.DAY_OF_MONTH);
        int yy = Integer.parseInt(y.substring(y.length()-2));

        //年
        if (yy > 33){
            yy = yy - 34;
        }
        if(yy < 10){
            reStr.append(yy);
        }else{
            //子母中不能使用 I与 O 2个字符
            if(yy >= 18 && yy < 23){
                yy += 1;
            }else if(yy >= 23){
                yy += 2;
            }
            reStr.append((char)(yy + 55));
        }
        //月
        if(m < 10){
            reStr.append(m);
        }else if( m == 10){
            reStr.append("A");
        }else if(m == 11){
            reStr.append("B");
        }else if(m == 12){
            reStr.append("C");
        }
        //日
        if(d < 10){
            reStr.append(d);
        }else{
            //子母中不能使用 I与 O 2个字符
            if(d >= 18 && d < 23){
                d += 1;
            }else if(d >= 23){
                d += 2;
            }
            reStr.append((char)(d + 55));
        }
        System.err.println("条码："+ reStr);
    }

    /**
     * 以FA0565E0100FEP5F6127为例
     * 1008黄岛洗碗机CP001下发规则附带GE码
     */
    @Test
    public void XWJGEcodeTest() {
        // 流水码流水号-1
        int count = 9956;
        //订单计划日期EST
        String EST = "2024-06-13 00:00:00";

        //GE号段里的（后台数据表：ge_config_table）
        String geProjectCode = "HCM9QWBWW";
        String geBrand = "GE";
        String geUrl = "1";
        String geCustomerCode = "HCM9QWWW";
        String industry_code = "BLCYX";
        String factory_code = "";

        /*
        以下为代码逻辑：
         */
        String string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String string1 = "ADFGHLMRSTVZ";
        int a = count % 26;
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(EST));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String timeStr = (c.get(Calendar.MONTH) + 1) + "" + c.get(Calendar.YEAR);
        timeStr = String.format("%6s", timeStr).replace(" ", "0");
        System.err.println("timeStr：" + timeStr);
        int y = c.get(Calendar.YEAR);
        int m = (c.get(Calendar.MONTH));
        String str = String.format("%5d", (count + 1)).replace(" ", "0");
        String mm = String.format("%2d", m + 1).replace(" ", "0");

        String Ecode = "M" + string.charAt(a) + geProjectCode;
        String Fcode = string1.charAt(m) + "" + string1.charAt((y - 2001) % 12) + industry_code + str + factory_code;
//        System.err.println(">>>"+string1.charAt((y - 2001) % 12));
        String Gcode = "S" + string.charAt(a) + Fcode;
        System.err.println("Gcode的第二位：" + string.charAt(a));
        String MY = mm + y;

        //有四种 品牌 生成的 二维码 是不同的
        String brank = geBrand;//品牌
        String[] branks = {"C", "P", "R"};
        if ("Haier".equalsIgnoreCase(brank)) {
            branks[0] = "CR";
            branks[1] = "PR";
            branks[2] = "RR";
        } else if ("Monogram".equalsIgnoreCase(brank)) {
            branks[0] = "CM";
            branks[1] = "PM";
            branks[2] = "RM";
        } else if ("GE".equalsIgnoreCase(brank)) {}
        String CUrl = geUrl + "&P=" + branks[0] + "&K=" + geCustomerCode + "&M=" + geProjectCode + "&S=" + Fcode + "&L=&D=" + MY;
        String PUrl = geUrl + "&P=" + branks[1] + "&K=" + geCustomerCode + "&M=" + geProjectCode + "&S=" + Fcode + "&L=&D=" + MY;
        String RUrl = geUrl + "&P=" + branks[2] + "&K=" + geCustomerCode + "&M=" + geProjectCode + "&S=" + Fcode + "&L=&D=" + MY;

        System.err.println("Ecode：" + Ecode + "\r\n" + "Fcode：" + Fcode + "\r\n" + "Gcode：" + Gcode + "\r\n" + "MY：" + MY + "\r\n" + "CUrl：" + CUrl + "\r\n" + "PUrl：" + PUrl + "\r\n" + "RUrl：" + RUrl);
    }

    @Test
    public void test01(){
        String string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Calendar c = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = df.parse("2023-02-18 00:00:00");
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.setTime(date);
        String timeStr = (c.get(Calendar.MONTH)+1)+""+c.get(Calendar.YEAR);
        /*
        *
        * SELECT
	IFNULL(mt.Fcode, '0') AS liushui
FROM
	(
		SELECT
			SUBSTRING(t.FCode, 4, 5) AS Fcode
		FROM
			base_barcode_sequence t
		LEFT JOIN ge_check_table t2 ON t.prodCode = t2.ProductCode
		WHERE
			t.my = #{timeStr}
	) mt
ORDER BY
	mt.Fcode DESC
LIMIT 1
        *
        */
//        timeStr = pdmDailyIssueDAO.getLiuShuiByMonthGE(timeStr,siteCode,"");
        timeStr = "03102";
        timeStr = String.format("%6s", timeStr).replace(" ","0");

//        System.err.println(timeStr);

        int a = Integer.valueOf(timeStr)%26;
        String ECode = "M"+string.charAt(a);

        System.err.println(ECode);
    }

    @Test
    public void test02(){
//        String string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String string1 = "ADFGHLMRSTVZ";
        Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR);
        int m = (c.get(Calendar.MONTH));
        String industry_code = "8";
        String factory_code = "K";
        int count =31-1;
        String str = String.format("%5d", (count + 1)).replace(" ", "0");
        String Fcode = string1.charAt(m) + "" + string1.charAt((y - 2001) % 12) + industry_code + str + factory_code;
        String mm = String.format("%2d", m + 1).replace(" ", "0");
        String MY = mm + y;
        System.err.println("Fcode>>>>"+Fcode);
        System.err.println("string1.charAt((y - 2001) % 12) >>>>"+string1.charAt((y - 2001) % 12) );
        System.err.println("str >>>>"+str );
        System.err.println("MY >>>>"+MY );
    }

}

