package com.RegExp.demo;

import com.RegExp.demo.entity.Bns_Pm_Operation;
import com.RegExp.demo.mapper.BnsPmOperation;
import org.junit.Test;
import org.junit.platform.commons.util.StringUtils;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;
import java.util.List;
import java.util.UUID;

@SpringBootTest
@RunWith(SpringRunner.class)
public class CreateCipherTest {

    @Autowired
    BnsPmOperation cipherMapper;

    /**
     * 批量生成校验码
     * @throws IOException
     */
    @Test
    public void getBatchCipher() throws IOException {
        String site_Code = "1042";

        List<Bns_Pm_Operation> barcode_list = cipherMapper.getBarcode(site_Code);
        String strUuid = "";
        String workuserBarcode = "";
        String workuserRandomBarcode = "";
        String strUuidST = "";
        String end = "";
        Boolean flag = true;

        // 写入文件路径
        String path = "D:\\test.txt";
        //清空数据重新写入
        if (new File(path).exists()) {
            new File(path).delete();
        }
        BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(path, true)));
        for (Bns_Pm_Operation barcode : barcode_list) {
            workuserBarcode = barcode.getWorkuserBarcode();
            workuserRandomBarcode = barcode.getWorkuserRandomBarCode();
            if (!StringUtils.isBlank(workuserRandomBarcode)) {
                workuserBarcode = workuserRandomBarcode;
            }
            strUuidST = workuserBarcode.substring(11, 16);
            end = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase().substring(0, 5);
            strUuid = strUuidST + end;
//            System.err.println(workuserBarcode + "：" + strUuid);

//            System.err.println(cipherMapper.validateJYM(strUuid, site_Code));
            // 判断检验码是否唯一，否：重新生成，是：继续生成下一条码的校验码
            flag = cipherMapper.validateJYM(strUuid, site_Code);
            if(!flag) cipherMapper.saveCipher(workuserBarcode,strUuid);
            while (flag) {
                strUuidST = workuserBarcode.substring(11, 16);
                end = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase().substring(0, 5);
                strUuid = strUuidST + end;
                if (cipherMapper.validateJYM(strUuid, site_Code)) {
                    flag = true;
                } else {
                    flag = false;
                    // 后台bns_pm_Operation条码表Cipher校验吗字段赋值，暂时关闭
//                    cipherMapper.saveCipher(workuserBarcode,strUuid);
                }
            }
            // 将结果写入M:\\test.txt文件
            out.write(workuserBarcode + "\t" + strUuid + "\r\n");

        }
        out.close();
    }

    /**
     * 单独处理
     */
    @Test
    public void getCipher() {
        String site_Code = "1042";
        String[] barcodeArray = {"CBAKH000E00CEHBG0780"};

        String strUuid = "";
        String strUuidST = "";
        String end = "";
        Boolean flag = true;
        for (int i = 0;i<barcodeArray.length;i++) {
            strUuidST = barcodeArray[i].substring(11, 16);
            end = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase().substring(0, 5);
            strUuid = strUuidST + end;
            // 判断检验码是否唯一，否：重新生成，是：继续生成下一条码的校验码
            flag = cipherMapper.validateJYM(strUuid, site_Code);
            while (flag) {
                strUuidST = barcodeArray[i].substring(11, 16);
                end = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase().substring(0, 5);
                strUuid = strUuidST + end;
                if (cipherMapper.validateJYM(strUuid, site_Code)) {
                    flag = true;
                } else {
                    flag = false;
                }
            }
            System.err.println(barcodeArray[i] + "\t" + strUuid);
        }
    }

}
