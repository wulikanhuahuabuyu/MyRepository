package com.RegExp.demo;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import com.RegExp.demo.mapper.RegExpMatchsMapper;
import com.RegExp.demo.service.DBChangeService;
import org.junit.Test;
import org.junit.platform.commons.util.StringUtils;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SpringBootTest
@RunWith(SpringRunner.class)
public class RegExpTest {

    @Autowired
    RegExpMatchsMapper regExpMatchsMapper;
    @Autowired
    DBChangeService dbChangeServiceImpl;

    /**
     * 多数据源实现正则匹配校验（注：因连接工厂数据库，故禁写delete、update、insert into 语句）
     *
     * @throws Exception
     */
    @Test
    public void RegExpT() throws Exception {
        String siteCode = "1037"; // 动态切换工厂数据库
        String content = "http://bbqk.com/3275ap";
        String productionLineCode = "";
        String workCellCode = "";

        char iscommon = '1';// 默认正则通用
        if (StringUtils.isNotBlank(productionLineCode) && StringUtils.isNotBlank(workCellCode)) {
            // 线体+工位正则，正则不通用
            iscommon = '0';
        }

        // 切换数据库
//        boolean b = dbChangeServiceImpl.changeDb(siteCode);
        // 若数据库url切换成功，则走正则校验
        int pageNum = 0;
        int pageSize = 0;
//        if (b) RegExpENC(siteCode, iscommon, productionLineCode, workCellCode, content,pageNum,pageSize);

        RegExpENC(siteCode, iscommon, productionLineCode, workCellCode, content, pageNum, pageSize);
    }


    /**
     * 正则测试封装
     *
     * @param siteCode           工厂号
     * @param iscommon           是否共用
     * @param productionLineCode 线体编码
     * @param workCellCode       站点编码
     * @param content            主观件内容
     */
    private void RegExpENC(String siteCode, char iscommon, String productionLineCode, String workCellCode, String content, int pageNum, int pageSize) {
        Pattern pattern;
        Matcher matcher;
        Boolean bool;
        int passRegCount = 0;
        try {
            List<Base_Regular_Configuration> reg = regExpMatchsMapper.findRegularTest(siteCode, iscommon, productionLineCode, workCellCode, pageNum, pageSize);
            if (reg.size() == 0) {
                System.err.println("无匹配正则！");
                return;
            }
            for (Base_Regular_Configuration list : reg) {
                try {
                    pattern = Pattern.compile(list.getRegularContent());
//                pattern = Pattern.compile(Pattern.quote(list.getRegularContent()));
                    matcher = pattern.matcher(content);
                    bool = matcher.matches();
//                System.err.println(">>>>>>" + list.getRegularContent());
                    if (bool == true) {
                        System.err.println("已匹配的正则内容如下:"
                                + "\n{"
                                + "\n \"条形编码\":\"" + list.getCodeType() + "\""
                                + "\n \"条码名称\":\"" + list.getBarCode() + "\""
                                + "\n \"正则内容\":\"" + list.getRegularContent() + "\""
                                + "\n}");
                        passRegCount += 1;
                    }
                } catch (Exception ex) {
                    System.err.println("-------------------👇正则表达式格式有误👇---------------"
                            + "\n{"
                            + "\n \"正则编码\":\"" + list.getRegularCode() + "\""
                            + "\n \"正则码\":\"" + list.getCodeType() + "\""
                            + "\n \"正则名称\":\"" + list.getBarCode() + "\""
                            + "\n \"正则内容\":\"" + list.getRegularContent() + "\""
                            + "\n}");
                    ex.printStackTrace();
                }

            }
//            System.out.println(passRegCount);
            if (passRegCount == 0) {
                System.err.println("已匹配正则数量为：" + passRegCount + ",无匹配正则！");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
    public void RegExpT2() throws Exception {

        List<String> list = new ArrayList<>();
        list.add("41523206ee0b49008ab2601fe59256ba");
        list.add("ff2ad6e5091b40e0adb208fed185e71b");
        list.add("0b71496576de49ab8524bfd1e243984c");
//        dbChangeService.changeDb("1001");
//        regExpMatchsMapper.exportRegular("1001",list);
        System.err.println("list>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + list);
    }



}
