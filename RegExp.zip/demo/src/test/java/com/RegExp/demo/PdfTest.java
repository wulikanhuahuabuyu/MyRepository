package com.RegExp.demo;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;
import org.junit.Test;

import java.io.*;

public class PdfTest {
    //	private static final String DEST = "C:\\Users\\肖化庚\\Desktop\\测试.pdf";
    private static final String FONT = "C:\\Windows\\Fonts\\simhei.ttf";

    @Test
    public void pdfTest() throws FileNotFoundException, DocumentException {

        String path = "C:\\Users\\xpp15\\Desktop\\故障现象-缺陷原因去重处理.txt";
        if (path.length() > 4) {
            String txtPath = path.substring(0, path.length() - 4) + ".pdf";
            Document document = new Document();

            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(txtPath));

            document.open();

            Font f1 = FontFactory.getFont(FONT, BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);

            document.add(new Paragraph(getText(path), f1));

            document.close();

            writer.close();

            System.out.println("转换完成！");
        }
    }

    /**
     * 读取txt文件中的文本内容
     *
     * @param path 需要传入的txt文件路径
     */
    public static String getText(String path) {

        StringBuffer buffer = new StringBuffer();
        try {
            File file = new File(path);

            System.out.println(file);

            if (file.isFile() && file.exists()) {

                InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "UTF-8");

                BufferedReader br = new BufferedReader(isr);
                String content = "";

                while ((content = br.readLine()) != null) {

                    buffer.append(System.lineSeparator() + content);
                    System.out.println("txt文件中的内容：\n" + content);
                }
                br.close();
            } else {
                System.out.println("文件不存在！");
            }
        } catch (Exception e) {
            e.getStackTrace();
        }

        return buffer.toString();
    }
}
