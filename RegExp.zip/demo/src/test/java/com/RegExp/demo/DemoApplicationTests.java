package com.RegExp.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

	@Test
	void contextLoads() {
	}

	private double pay = 1.0;
	@Test
	public void teest01() {

		int num = 1;
		switch(num){
			case 1:
				pay = pay*0.5;
				if(num==1){
					
					System.err.println("if语句执行了");
				}
				break;
			case 2:
				pay = pay*0.8;
				break;
		}
//		String year="";
//		year=""+Integer.parseInt(String.valueOf("M"));
//		System.err.println(year);
	}

}
