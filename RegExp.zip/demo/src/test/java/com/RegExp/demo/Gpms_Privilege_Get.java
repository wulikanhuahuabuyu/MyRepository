package com.RegExp.demo;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class Gpms_Privilege_Get {
    @Test
    public void Gpms_Privilege_GetTest() {
        /**
         * @diCode
         * Region 区域
         * Channel 渠道
         * Product 产品
         * Brand 品牌
         * */
        String userCode = "01464100";
        String diCode = "C";

        switch (diCode) {
            case "R":
                diCode = "?diCode=Region";
                break;
            case "C":
                diCode = "?diCode=Channel";
                break;
            case "P":
                diCode = "?diCode=Product";
                break;
            case "B":
                diCode = "?diCode=Brand";
                break;
            default:
                diCode = "";
        }

        OkHttpClient client = new OkHttpClient().newBuilder().build();

        Request request = new Request.Builder().url("http://gpms-privilege.qd-aliyun-dmz-ack-internal.haier.net/userDataPermission/listByUserNoAndDiCode/3897a40abbe07dde6ee21971393ebd5a/" + userCode + diCode).method("GET", null).build();

        Response response;
        try {
            response = client.newCall(request).execute();
            String body_json = response.body().string();
//            System.err.println(body_json);

            JSONObject jsonObject = new JSONObject(body_json);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            JSONObject jsonObject1;

            // 写入文件路径
            String path = "D:\\Gpms_Privilege_GetTest.txt";
            //清空数据重新写入
            if (new File(path).exists()) {
                new File(path).delete();
            }
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path, true)));

            for (int i = 0; i < jsonArray.length(); i++) {
                jsonObject1 = jsonArray.getJSONObject(i);
                System.err.println(
                        jsonObject1.getString("propNameCn")
                );

                out.write(jsonObject1.getString("propNameCn") + "\r\n");
            }
            out.close();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }

    }
}
