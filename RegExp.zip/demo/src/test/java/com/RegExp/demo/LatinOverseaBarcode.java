package com.RegExp.demo;

import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;

@SpringBootTest
@RunWith(SpringRunner.class)
public class LatinOverseaBarcode {
    /**
     * 拉美序列号--海外条码通过接口获取
     * http://interface.qd-hongdao.haier.net/imInterfaces/latin/queryList
     */
    @Test
    public void LatinOverseaBarcodeTest() {
        String body_json_str = "[{\n" +
                "\t\"siteCode\":\"1042\",\n" +
                "\t\"orderCode\":\"20001567441\"\n" +
                "}]";

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, body_json_str);
        Request request = new Request.Builder()
                .url("http://interface.qd-hongdao.haier.net/imInterfaces/latin/queryList")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .build();
        try {
            Response response = client.newCall(request).execute();
            String body_json = response.body().string();
//            System.err.println(body_json);

            JSONObject jsonObject = new JSONObject(body_json);
            JSONArray jsonArray = jsonObject.getJSONArray("data");
            JSONObject jsonObject2 = jsonArray.getJSONObject(0);
            JSONArray jsonArray2 = jsonObject2.getJSONArray("workCodeVoList");
//            System.err.println("jsonObject2>>>>"+jsonObject2);
            JSONObject jsonObject1;

            // 写入文件路径
            String path = "D:\\LatinOverseaBarcodeTest.txt";
            //清空数据重新写入
            if (new File(path).exists()) {
                new File(path).delete();
            }
            BufferedWriter out = new BufferedWriter(
                    new OutputStreamWriter(new FileOutputStream(path, true)));

            for (int i = 0; i < jsonArray2.length(); i++) {
                jsonObject1 = jsonArray2.getJSONObject(i);
//                System.err.println("jsonObject1????????"+jsonObject1);
                System.err.println(
                        jsonObject1.getString("barCode") + "\t" +
                                jsonObject1.getString("foreignCode")
                );

                out.write(
                        jsonObject1.getString("barCode") + "\t" +
                                jsonObject1.getString("foreignCode") + "\n"
                );
            }
            out.close();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }
}
