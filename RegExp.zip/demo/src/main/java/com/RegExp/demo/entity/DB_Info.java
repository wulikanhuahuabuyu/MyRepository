package com.RegExp.demo.entity;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class DB_Info implements Serializable {
    public String siteCode;
    public String siteName;
    public String dbUrl;
    public String active;
    public String wmsFlag;
    public String wmsurlbg;
    public String wmsurlqt;
    public String dburlxxdr;
    public String isArchive;
    public String monthLimit;
    public String industryCode;
    public String secondaryBbUrl;

}
