package com.RegExp.demo.util;

import com.alibaba.excel.EasyExcel;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

/*
Excel导出（。xls、.xlsx、csv）
 */
public class BrowserDownloadExcel {
    /**
     * 。xls、.xlsx导出
     *
     * @param excelName 文件名
     * @param cla       数据导出所对应的实体类（base_regular_configuration）
     * @param list      导出的数据
     * @param fileType  文件类型（。xls、.xlsx）
     */
    public static void downloadUnfilledToXlsx(String excelName, HttpServletResponse response, Class cla, List list, String fileType) throws IOException {
        if (fileType.equals(".xlsx"))
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        if (fileType.equals(".xls"))
            response.setContentType("application/vnd.ms-excel");

        response.setCharacterEncoding("utf-8");

        // 这里URLEncoder.encode可以防止中文乱码
        String fileName = URLEncoder.encode(excelName, StandardCharsets.UTF_8).replaceAll("\\+", "%20");
        response.setHeader("Content-Disposition", "attachment;filename*=utf-8''" + fileName + fileType);
        if (fileType.equals(".xlsx") || fileType.equals(".xls"))
            EasyExcel.write(response.getOutputStream(), cla).registerConverter(new CharConverter()).sheet(excelName).doWrite(list);
//            EasyExcel.write("D:\\test.xls", cla).registerConverter(new CharConverter()).sheet(excelName).doWrite(list);

    }


}
