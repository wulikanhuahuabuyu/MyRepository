package com.RegExp.demo.controller;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import com.RegExp.demo.service.DBChangeService;
import com.RegExp.demo.service.ExcelExportService;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

@RestController
@RequestMapping("/")
public class ExcelExportController {
    @Autowired
    ExcelExportService excelExportService;
    @Autowired
    DBChangeService dbChangeService;
    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;

    @PostMapping(value = "export")
    @ResponseBody
    public void exportExcel(HttpServletResponse response, @RequestBody Base_Regular_Configuration datalist) throws IOException  {
        System.err.println("进入了exportExcel()方法。。。。sitecode："+datalist.getSiteCode());
        // 设置响应头信息
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode("exported_data.xlsx", "UTF-8"));
        try {
            boolean b = dbChangeService.changeDb(datalist.getSiteCode());
            // 调用导出接口
            if(b) excelExportService.exportData(datalist,response);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }











}
