package com.RegExp.demo.mapper;

import com.RegExp.demo.entity.Pm_Production_Lines_t;

import java.util.List;

public interface PmProductionLinesTMapper {
    List<Pm_Production_Lines_t> findAllLines(String siteCode);

}
