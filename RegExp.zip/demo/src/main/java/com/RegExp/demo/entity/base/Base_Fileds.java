package com.RegExp.demo.entity.base;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentStyle;
import com.alibaba.excel.annotation.write.style.HeadFontStyle;
import com.alibaba.excel.annotation.write.style.HeadStyle;
import com.alibaba.excel.enums.poi.BorderStyleEnum;
import com.alibaba.excel.enums.poi.FillPatternTypeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@Data
//@Setter
//@Getter
@ToString
@HeadStyle(fillPatternType = FillPatternTypeEnum.SOLID_FOREGROUND, fillForegroundColor = 30)
@HeadFontStyle(color = 1)
public abstract class Base_Fileds implements Serializable {
//    @ExcelProperty("工厂号")
    @ExcelIgnore
    private String siteCode;
    @ExcelIgnore
    private String[] ids;
    @ExcelIgnore
    private String codeContent;
    @ExcelIgnore
    private String fileType;
    @ExcelIgnore
    private String isFilterRepeat;


    @ColumnWidth(12)
    @ExcelProperty("创建人")
    private String createBy;

    @ExcelProperty("创建日期")
    @DateTimeFormat("yyyy-MM-dd hh:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ColumnWidth(12)
    @ContentStyle(borderLeft = BorderStyleEnum.THIN, borderTop = BorderStyleEnum.THIN, borderRight = BorderStyleEnum.THIN, borderBottom = BorderStyleEnum.THIN,
//              leftBorderColor = 7,topBorderColor = 7,rightBorderColor = 7,bottomBorderColor = 7
            leftBorderColor = 40,topBorderColor = 40,rightBorderColor = 40,bottomBorderColor = 40
    )
    private Date createDate;

    @ExcelProperty("创建人")
    @ColumnWidth(12)
    private String lastUpdateBy;

    @ExcelProperty("修改日期")
    @DateTimeFormat("yyyy-MM-dd hh:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ColumnWidth(12)
    @ContentStyle(borderLeft = BorderStyleEnum.THIN, borderTop = BorderStyleEnum.THIN, borderRight = BorderStyleEnum.THIN, borderBottom = BorderStyleEnum.THIN,
//              leftBorderColor = 7,topBorderColor = 7,rightBorderColor = 7,bottomBorderColor = 7
            leftBorderColor = 40,topBorderColor = 40,rightBorderColor = 40,bottomBorderColor = 40
    )
    private Date lastUpdateDate;

    @ExcelIgnore
    private char active;

}
