package com.RegExp.demo.entity;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

@Data
public class User {
    @ExcelProperty("姓名")
    private String username;
    @ExcelProperty("学科")
    private String project;
    @ExcelProperty("分数")
    private String source;
}
