package com.RegExp.demo.entity;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.ceil;

public class PageView<T> {

    List<T> dataList=new ArrayList<>();
    List<T> errDataList=new ArrayList<>();
    Integer totalCount = 0;
    Integer unionRepeatTotalCount = 0;
    Integer prePage = 1;
    Integer currentPage = 1;
    Integer nextPage = 1;
    Integer totalPage = 1;
    Integer pageSize = 10;

    public PageView() {

    }

    public PageView(List<T> reg, int regTotalCount) {
    }

    public Integer getTotalPage() {
        System.err.println("totalCount----" + totalCount + "，pageSize----" + pageSize);
        return (int) ceil((double) (totalCount == 0 ? 1 : totalCount) / (pageSize == 0 ? 10 : pageSize));
    }

    public Integer getNextPage() {
        System.err.println("totalPage>>>>" + getTotalPage());
        return getCurrentPage() == null ? 1 : getCurrentPage().equals(getTotalPage()) ? getCurrentPage() : getCurrentPage() + 1;
    }

    public Integer getCurrentPage() {
        return currentPage == null ? 1 : currentPage;
    }

    public Integer getPrePage() {
        System.err.println("prePage>>>" + prePage);
        return (currentPage - 1) == 0 ? 1 : currentPage - 1;
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public List<T> getDataList() {
        return dataList;
    }

    public void setDataList(List<T> dataList) {
        this.dataList = dataList;
    }

    public List<T> getErrDataList() {
        return errDataList;
    }

    public void setErrDataList(List<T> errDataList) {
        this.errDataList = errDataList;
    }

    public void setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
    }

    public Integer getUnionRepeatTotalCount() {
        return unionRepeatTotalCount;
    }

    public void setUnionRepeatTotalCount(Integer unionRepeatTotalCount) {
        this.unionRepeatTotalCount = unionRepeatTotalCount;
    }

    public void setPrePage(Integer prePage) {
        this.prePage = prePage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage == 0 ? 1 : currentPage;
    }

    public void setNextPage(Integer nextPage) {
        this.nextPage = nextPage;
    }

    public void setTotalPage(Integer totalPage) {
        this.totalPage = totalPage;
    }

    public Integer getPageSize() {
        return pageSize == 0 ? 10 : pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @Override
    public String toString() {
        return "PageView{" +
                "dataList=" + dataList +
                "errDataList=" + errDataList +
                ", totalCount=" + totalCount +
                ", unionRepeatTotalCount=" + unionRepeatTotalCount +
                ", prePage=" + prePage +
                ", currentPage=" + currentPage +
                ", nextPage=" + nextPage +
                ", totalPage=" + totalPage +
                '}';
    }
}
