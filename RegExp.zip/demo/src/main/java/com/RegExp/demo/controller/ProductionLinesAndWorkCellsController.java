package com.RegExp.demo.controller;

import com.RegExp.demo.entity.Pm_Production_Lines_t;
import com.RegExp.demo.entity.Pm_Work_Cells_t;
import com.RegExp.demo.service.DBChangeService;
import com.RegExp.demo.service.PmProductionLinesTService;
import com.RegExp.demo.service.PmWorkCellsTService;
import com.RegExp.demo.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.RegExp.demo.enum_state_msg.ResponseStateAndMsg.EMPTYRESULT_STATE_MSG;
import static com.RegExp.demo.enum_state_msg.ResponseStateAndMsg.SUCCESS__STATE_MSG;

@RestController
@RequestMapping("/")
public class ProductionLinesAndWorkCellsController {

    @Autowired
    DBChangeService dbChangeService;
    @Autowired
    PmProductionLinesTService pmProductionLinesTService;
    @Autowired
    PmWorkCellsTService pmWorkCellsTService;

    @GetMapping("getlineList")
    public JsonResult<List<Pm_Production_Lines_t>> getProductionLines(@RequestParam("siteCode") String siteCode) {
        List<Pm_Production_Lines_t> lineList = null;
        try {
            boolean dbFlahg = dbChangeService.changeDb(siteCode);
            if (dbFlahg) {
                lineList = pmProductionLinesTService.findAllLines(siteCode);
                if (!lineList.isEmpty()) {
                    return new JsonResult<>(SUCCESS__STATE_MSG.getState(), lineList, SUCCESS__STATE_MSG.getMsg());
                } else {
                    return new JsonResult<>(EMPTYRESULT_STATE_MSG.getState(), lineList, EMPTYRESULT_STATE_MSG.getMsg());
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new JsonResult<>(SUCCESS__STATE_MSG.getState(), lineList, SUCCESS__STATE_MSG.getMsg());
    }

    @GetMapping("getCellList")
    public JsonResult<List<Pm_Work_Cells_t>> getWorkCells(@RequestParam("siteCode") String siteCode,@RequestParam("productionlineId") String productionlineId) {
        List<Pm_Work_Cells_t> workCellList = null;
        try {
            boolean dbFlahg = dbChangeService.changeDb(siteCode);
            if (dbFlahg) {
                workCellList = pmWorkCellsTService.findAllCells(siteCode,productionlineId);
                if (!workCellList.isEmpty()) {
                    return new JsonResult<>(SUCCESS__STATE_MSG.getState(), workCellList, SUCCESS__STATE_MSG.getMsg());
                } else {
                    return new JsonResult<>(EMPTYRESULT_STATE_MSG.getState(), workCellList, EMPTYRESULT_STATE_MSG.getMsg());
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new JsonResult<>(SUCCESS__STATE_MSG.getState(), workCellList, SUCCESS__STATE_MSG.getMsg());
    }
}
