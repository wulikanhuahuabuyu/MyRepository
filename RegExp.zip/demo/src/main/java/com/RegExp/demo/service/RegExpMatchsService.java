package com.RegExp.demo.service;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import com.RegExp.demo.entity.PageView;

public interface RegExpMatchsService {
    PageView<Base_Regular_Configuration> findRegular(Base_Regular_Configuration baseRegularConfiguration,int pageNum,int pageSize);
    PageView<Base_Regular_Configuration> findRepeatRegular(String siteCode,int pageNum, int pageSize);

}
