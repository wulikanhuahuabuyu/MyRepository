package com.RegExp.demo.service.impl;

import com.RegExp.demo.entity.Pm_Work_Cells_t;
import com.RegExp.demo.mapper.PmWorkCellsTMapper;
import com.RegExp.demo.service.PmWorkCellsTService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class PmWorkCellsTServiceImpl implements PmWorkCellsTService {

    @Autowired
    PmWorkCellsTMapper pmWorkCellsTMapper;

    @Override
    public List<Pm_Work_Cells_t> findAllCells(String siteCode, String productionlineId) {
        return pmWorkCellsTMapper.findAllCells(siteCode,productionlineId);
    }
}
