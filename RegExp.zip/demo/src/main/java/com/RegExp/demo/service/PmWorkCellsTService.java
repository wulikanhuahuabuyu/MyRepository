package com.RegExp.demo.service;

import com.RegExp.demo.entity.Pm_Work_Cells_t;

import java.util.List;

public interface PmWorkCellsTService {
    List<Pm_Work_Cells_t> findAllCells(String siteCode, String productionlineId);
}
