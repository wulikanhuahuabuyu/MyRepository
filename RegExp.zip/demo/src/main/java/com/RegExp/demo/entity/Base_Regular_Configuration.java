package com.RegExp.demo.entity;

import com.RegExp.demo.entity.base.Base_Fileds;
import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.*;
import com.alibaba.excel.enums.poi.BorderStyleEnum;
import com.alibaba.excel.enums.poi.FillPatternTypeEnum;
import lombok.*;

import java.io.Serializable;

/**
 * xxxColor：https://poi.apache.org/apidocs/dev/org/apache/poi/ss/usermodel/IndexedColors.html（public enum IndexedColors extends java.lang.Enum<IndexedColors> 👉 Enum Constant Detail）
 * https://blog.csdn.net/qq_17586173/article/details/130706543 颜色显化
 */
@EqualsAndHashCode(callSuper = true)
@Data
//@Setter
//@Getter
@ToString(callSuper = true)
@HeadStyle(fillPatternType = FillPatternTypeEnum.SOLID_FOREGROUND, fillForegroundColor = 30,
        borderLeft = BorderStyleEnum.THIN, borderTop = BorderStyleEnum.THIN, borderRight = BorderStyleEnum.THIN, borderBottom = BorderStyleEnum.THIN,
//              leftBorderColor = 7,topBorderColor = 7,rightBorderColor = 7,bottomBorderColor = 7
        leftBorderColor = 40,topBorderColor = 40,rightBorderColor = 40,bottomBorderColor = 40
)
@HeadFontStyle(color = 1,fontHeightInPoints = 12)
@ContentStyle(dataFormat = 49, borderLeft = BorderStyleEnum.THIN, borderTop = BorderStyleEnum.THIN, borderRight = BorderStyleEnum.THIN, borderBottom = BorderStyleEnum.THIN,
//              leftBorderColor = 7,topBorderColor = 7,rightBorderColor = 7,bottomBorderColor = 7
              leftBorderColor = 40,topBorderColor = 40,rightBorderColor = 40,bottomBorderColor = 40
)
@HeadRowHeight(20)

public class Base_Regular_Configuration extends Base_Fileds implements Serializable {
    @ExcelIgnore
    private String id;

    @ExcelProperty("正则编码")
    @ColumnWidth(12)
    private String regularCode;

    @ExcelProperty("正则码")
    @ColumnWidth(12)
    private String codeType;

    @ExcelProperty("正则名称")
    @ColumnWidth(12)
    private String barCode;

    @ExcelProperty("正则内容")
    @ColumnWidth(36)
    private String regularContent;

    @ExcelProperty("线体编码")
    @ColumnWidth(12)
    private String productionLineCode;

    @ExcelProperty("线体名称")
    @ColumnWidth(12)
    private String productionLineName;

    @ExcelProperty("站点编码")
    @ColumnWidth(12)
    private String workCellCode;

    @ExcelProperty("工位名称")
    @ColumnWidth(12)
    private String workCellName;

    @ExcelProperty(value = "是否共用")
    @ColumnWidth(12)
    private char isCommon;

    @ExcelProperty(value = "是否启用")
    @ColumnWidth(12)
    private char active;

    @ExcelIgnore
    private char isCheck;
    @ExcelIgnore
    private String EnterpriseCode;
    @ExcelIgnore
    private String SiteId;
    @ExcelIgnore
    private String EnterpriseId;

//    @ExcelIgnore
//    private Pm_Production_Lines_t pmProductionLinesT;
//    @ExcelIgnore
//    private Pm_Work_Cells_t pmWorkCellsT;


}
