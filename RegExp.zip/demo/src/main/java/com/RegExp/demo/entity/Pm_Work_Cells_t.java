package com.RegExp.demo.entity;

import com.RegExp.demo.entity.base.Base_Fileds;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@ToString
@Getter
public class Pm_Work_Cells_t extends Base_Fileds implements Serializable {
    private String ProductionLineId;
    private String WorkCellCode;

    private String WorkCellDesc;
}
