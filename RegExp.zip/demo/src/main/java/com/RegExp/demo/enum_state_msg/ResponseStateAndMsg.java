package com.RegExp.demo.enum_state_msg;

import lombok.Getter;

@Getter
public enum ResponseStateAndMsg {
    SUCCESS__STATE_MSG(200,"查询成功"),
    EMPTYRESULT_STATE_MSG(204,"查询结果为空"),
    WARNING__STATE_MSG(400,"无该工厂的数据库链接"),
    ERROR_STATE_MSG(300,"查询失败");

    private final Integer state;
    private final String msg;

     ResponseStateAndMsg(Integer state, String msg) {
         this.state=state;
         this.msg=msg;
     }

    @Override
    public String toString() {
        return "ResponseStateAndMsg{" +
                "state=" + state +
                ", msg='" + msg + '\'' +
                '}';
    }
}
