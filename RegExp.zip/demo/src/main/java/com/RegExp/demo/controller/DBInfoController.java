package com.RegExp.demo.controller;

import com.RegExp.demo.entity.DB_Info;
import com.RegExp.demo.service.DBChangeService;
import com.RegExp.demo.util.DBContextHolder;
import com.RegExp.demo.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.RegExp.demo.enum_state_msg.ResponseStateAndMsg.ERROR_STATE_MSG;
import static com.RegExp.demo.enum_state_msg.ResponseStateAndMsg.SUCCESS__STATE_MSG;

@RestController
@RequestMapping("/")
public class DBInfoController {
    @Autowired
    DBChangeService dbChangeService;

    @GetMapping(value = "getDB", produces = "application/json; charset=utf-8")
    public JsonResult<List<DB_Info>> getDBCodeName(String siteCode) {
        System.err.println("getDBCodeName==>siteCode:" + siteCode);
        String datasource = DBContextHolder.getDataSource();
        System.err.println("datasource>>>>>>>>>>>：" + datasource);
        List<DB_Info> db_info=List.of();
        if (siteCode.isEmpty()) {
            // 防止前端页面刷新后还保留上一工厂数据库连接
            DBContextHolder.clearDataSource();
            System.err.println("页面刷新后，数据库连接已重置》》siteCode："+siteCode);
        }
        // 获取工厂列表
        if (datasource == null) {
            db_info = dbChangeService.getDBCodeName();
        }
        try {
            if (!db_info.isEmpty()) {
                return new JsonResult<>(SUCCESS__STATE_MSG.getState(), db_info, SUCCESS__STATE_MSG.getMsg());
            } else {
                return new JsonResult<>(ERROR_STATE_MSG.getState(), db_info, ERROR_STATE_MSG.getMsg());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(ERROR_STATE_MSG.getState(), db_info, ERROR_STATE_MSG.getMsg());
        }

    }
}
