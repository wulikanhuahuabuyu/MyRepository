package com.RegExp.demo.service.impl;

import com.RegExp.demo.datasource.DynamicDataSource;
import com.RegExp.demo.entity.DB_Info;
import com.RegExp.demo.mapper.DBSourceMapper;
import com.RegExp.demo.service.DBChangeService;
import com.RegExp.demo.util.DBContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DBChangeServiceImpl implements DBChangeService {
//    private String preDatasource = "";

    @Autowired
    DBSourceMapper dbSourceMapper;
    @Autowired
    DynamicDataSource dynamicDataSource;

    @Override
    public List<DB_Info> getDB(String siteCode) {
        return dbSourceMapper.getDB(siteCode);
    }

    @Override
    public List<DB_Info> getDBCodeName() {
        return dbSourceMapper.getDBCodeName();
    }

    @Override
    public boolean changeDb(String datasourceId) throws Exception {
//        System.err.println("preDatasource:" + preDatasource + "         datasourceId:" + datasourceId);
        //默认切换到主数据源,进行整体资源的查找
//        DBContextHolder.clearDataSource();
        System.err.println("DBContextHolder.getDataSource()：" + DBContextHolder.getDataSource());
        if (DBContextHolder.getDataSource() == null) {
            List<DB_Info> dataSourcesList = dbSourceMapper.getDB(datasourceId);
            for (DB_Info dataSource : dataSourcesList) {
                if (dataSource.getSiteCode().equals(datasourceId)) {
                    System.err.println("需要使用的的数据源已经找到,datasourceId是：" + dataSource.getSiteCode());
                    //创建数据源连接&检查 若存在则不需重新创建
                    dynamicDataSource.createDataSourceWithCheck(dataSource);
                    //切换到该数据源
                    DBContextHolder.setDataSource(dataSource.getSiteCode());
                    return true;
                }
            }
        } else {
            //如果切换到主数据源,进行整体资源的查找
            DBContextHolder.clearDataSource();
            List<DB_Info> dataSourcesList = dbSourceMapper.getDB(datasourceId);
            if (!dataSourcesList.isEmpty()) {
                for (DB_Info dataSource : dataSourcesList) {
                    if (dataSource.getSiteCode().equals(datasourceId)) {
                        // 创建新数据源
                        dynamicDataSource.createDataSource(dataSource);
                        //切换到该数据源
                        DBContextHolder.setDataSource(datasourceId);
                        System.err.println("数据源不是null》》》：：" + datasourceId);
                    }
                    return true;
                }
            } else {
                System.err.println("无该数据库（"+datasourceId+"）链接");
                return false;
            }
        }
        return false;

    }

}