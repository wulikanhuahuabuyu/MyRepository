package com.RegExp.demo.controller;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import com.RegExp.demo.entity.PageView;
import com.RegExp.demo.service.DBChangeService;
import com.RegExp.demo.service.RegExpMatchsService;
import com.RegExp.demo.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import static com.RegExp.demo.enum_state_msg.ResponseStateAndMsg.*;

@RestController
@RequestMapping("/")
public class RegExpController {

    @Autowired
    RegExpMatchsService regExpMatchsService;
    @Autowired
    DBChangeService dbChangeService;

    @GetMapping(value = "list", produces = "application/json; charset=utf-8")
//    public JsonResult<PageView<Base_Regular_Configuration>> getRegList(@RequestParam("siteCode") String siteCode, @RequestParam("regularCode") String regularCode, @RequestParam("codeType") String codeType, @RequestParam("codeContent") String codeContent, @RequestParam("isCommon") String isCommon, @RequestParam("productionLineCode") String productionLineCode, @RequestParam("workCellCode") String workCellCode,@RequestParam("isFilterRepeat") String isFilterRepeat, @RequestParam("pageNum") int pageNum, @RequestParam("pageSize") int pageSize) {
    public JsonResult<PageView<Base_Regular_Configuration>> getRegList(@ModelAttribute Base_Regular_Configuration baseRegularConfiguration, @RequestParam("pageNum") int pageNum, @RequestParam("pageSize") int pageSize) {
        PageView<Base_Regular_Configuration> regList = null;
        String regularContent = baseRegularConfiguration.getRegularContent();
        if (!regularContent.isEmpty()) {
            baseRegularConfiguration.setRegularContent(regularContent.replace(".","\\.").replace("?","\\?"));
        }
        try {
            boolean b = dbChangeService.changeDb(baseRegularConfiguration.getSiteCode());
            if (b) {
                System.err.println("--------------进入了findRegular()--------------");
                if (baseRegularConfiguration.getIsFilterRepeat().equals("0")) {// 非查重：不筛选正则编码重复
                    regList = regExpMatchsService.findRegular(baseRegularConfiguration, pageNum, pageSize);
                } else {// 查重：筛选正则编码重复
                    regList = regExpMatchsService.findRepeatRegular(baseRegularConfiguration.getSiteCode(), pageNum, pageSize);
                }
//                System.err.println("regList>>>??????>>>>"+regList);
                if (regList.getDataList().isEmpty()) {
                    return new JsonResult<>(EMPTYRESULT_STATE_MSG.getState(), regList, EMPTYRESULT_STATE_MSG.getMsg());
                }
            } else {
                return new JsonResult<>(WARNING__STATE_MSG.getState(), regList, WARNING__STATE_MSG.getMsg());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonResult<>(ERROR_STATE_MSG.getState(), e.toString());
        }
        return new JsonResult<>(SUCCESS__STATE_MSG.getState(), regList, SUCCESS__STATE_MSG.getMsg());
    }

}
