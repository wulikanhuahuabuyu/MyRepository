package com.RegExp.demo.entity;

import com.RegExp.demo.entity.base.Base_Fileds;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@ToString
public class Pm_Production_Lines_t extends Base_Fileds implements Serializable {
    private static final long serialVersionUID = 1L;
    private String ProductionLineId;
    private String ProductionLineCode;
    private String ProductionLineDesc;

}
