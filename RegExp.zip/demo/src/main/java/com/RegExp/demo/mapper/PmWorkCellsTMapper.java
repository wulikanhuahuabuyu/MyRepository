package com.RegExp.demo.mapper;

import com.RegExp.demo.entity.Pm_Work_Cells_t;

import java.util.List;

public interface PmWorkCellsTMapper {
    List<Pm_Work_Cells_t> findAllCells(String siteCode, String productionlineId);
}
