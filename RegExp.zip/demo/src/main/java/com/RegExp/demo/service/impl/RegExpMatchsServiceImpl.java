package com.RegExp.demo.service.impl;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import com.RegExp.demo.entity.PageView;
import com.RegExp.demo.mapper.RegExpMatchsMapper;
import com.RegExp.demo.service.RegExpMatchsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Service
public class RegExpMatchsServiceImpl implements RegExpMatchsService {
    @Autowired
    RegExpMatchsMapper regExpMatchsMapper;

    @Override
    public PageView<Base_Regular_Configuration> findRegular(Base_Regular_Configuration baseRegularConfiguration, int pageNum, int pageSize) {
        System.err.println("进入了findRegular()方法");
        return RegExpENC(baseRegularConfiguration, pageNum, pageSize);
    }

    @Override
    public PageView<Base_Regular_Configuration> findRepeatRegular(String siteCode ,int pageNum, int pageSize) {
        System.err.println("进入了findRepeatRegular()方法");
        PageView<Base_Regular_Configuration> pageView = new PageView<>();
        // 根据页码、每页显示条数查询
        int off_set = (pageNum - 1) * pageSize;
        pageView.setTotalCount(regExpMatchsMapper.getRepeatRegularTotalCount(siteCode));
        pageView.setUnionRepeatTotalCount(regExpMatchsMapper.getUnionRepeatRegularTotalCount(siteCode));
        pageView.setDataList(regExpMatchsMapper.getRepeatRegular(siteCode,off_set,pageSize));
        pageView.setCurrentPage(pageNum);
        pageView.setPageSize(pageSize);
        return pageView;
    }

    /**
     *  正则匹配封装
     */
    private PageView<Base_Regular_Configuration> RegExpENC(Base_Regular_Configuration baseRegularConfiguration, int pageNum, int pageSize) {
        System.err.println("进入了RegExpENC()方法");
//        System.err.println("pageNum：" + pageNum + ",pageSize:" + pageSize);
        PageView<Base_Regular_Configuration> pageView = new PageView<>();
        // 存放有效正则
        List<Base_Regular_Configuration> dataList = new ArrayList<>();

        // 存放格式错误正则
        List<Base_Regular_Configuration> errDataList = new ArrayList<>();
        Pattern pattern;
        Matcher matcher;
        Boolean bool;
        int passRegCount = 0;
        // 统计总数
        int regTotalCount = regExpMatchsMapper.findRegularTotalCount(baseRegularConfiguration);
        // 根据页码、每页显示条数查询
        int off_set = (pageNum - 1) * pageSize;
        List<Base_Regular_Configuration> reg = regExpMatchsMapper.findRegular(baseRegularConfiguration, off_set, pageSize);
        if (StringUtils.isEmpty(baseRegularConfiguration.getCodeContent())) {
//            System.err.println("regTotalCount>>>" + regTotalCount);
            pageView.setDataList(reg);
            pageView.setTotalCount(regTotalCount);
            pageView.setCurrentPage(pageNum);
            pageView.setPageSize(pageSize);
            return pageView;
        }
        try { // 正则匹配
            if (reg.isEmpty()) {
                System.err.println("无匹配正则！");
                return pageView;
            }
            for (Base_Regular_Configuration list : reg) {
                try {
                    pattern = Pattern.compile(list.getRegularContent());
//                pattern = Pattern.compile(Pattern.quote(list.getRegularContent()));
                    matcher = pattern.matcher(baseRegularConfiguration.getCodeContent());
                    bool = matcher.matches();
//                System.err.println(">>>>>>" + list.getRegularContent());
                    if (bool == true) {
                        System.err.println("已匹配的正则内容如下:"
                                + "\n{"
                                + "\n \"正则编码\":\"" + list.getRegularCode() + "\""
                                + "\n \"正则码\":\"" + list.getCodeType() + "\""
                                + "\n \"正则名称\":\"" + list.getBarCode() + "\""
                                + "\n \"正则内容\":\"" + list.getRegularContent() + "\""
                                + "\n}");
                        passRegCount += 1;
//                        System.err.println("list>>>>>>>>>>>" + list);
                        dataList.add(list);
                    }
                } catch (Exception ex) {
                    errDataList.add(list);
                    System.err.println("-------------------👇正则表达式格式有误👇---------------"
                                    + "\n{"
                                    + "\n \"正则编码\":\"" + list.getRegularCode() + "\""
                                    + "\n \"正则码\":\"" + list.getCodeType() + "\""
                                    + "\n \"正则名称\":\"" + list.getBarCode() + "\""
                                    + "\n \"正则内容\":\"" + list.getRegularContent() + "\""
                                    + "\n}");
                    ex.printStackTrace();
                }

            }
            System.out.println(passRegCount);

            if (passRegCount == 0) {
                System.err.println("已匹配正则数量为：" + passRegCount + ",无匹配正则！");
                return pageView;
            }
            // 前端只显示已匹配的正则，格式错误的正则红色背景显示
            pageView.setDataList(dataList);
            pageView.setErrDataList(errDataList);
            pageView.setTotalCount(passRegCount);
            pageView.setCurrentPage(pageNum);
            pageView.setPageSize(pageSize);
            return pageView;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pageView;
    }

}
