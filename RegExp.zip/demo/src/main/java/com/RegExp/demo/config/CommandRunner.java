package com.RegExp.demo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * 项目启动监听预加载spring配置，实现自动打开浏览器访问项目
 */
@Component
public class CommandRunner implements CommandLineRunner {

    @Value("${spring.web.loginUrl}")
    private String loginUrl;
    @Value("${spring.auto.isOpen}")
    private boolean isOpen;

    @Override
    public void run(String... args) throws Exception {
        if (isOpen) {
            try {
                System.err.println("正在打开谷歌浏览器访问项目网址...\r\n" + loginUrl);
                Runtime.getRuntime().exec("cmd /c start chrome " + loginUrl);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
