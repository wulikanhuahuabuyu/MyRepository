package com.RegExp.demo.service;

import com.RegExp.demo.entity.DB_Info;

import java.util.List;

public interface DBChangeService {

    List<DB_Info> getDB(String siteCode);
    List<DB_Info> getDBCodeName();

    boolean changeDb(String datasourceId) throws Exception;

}