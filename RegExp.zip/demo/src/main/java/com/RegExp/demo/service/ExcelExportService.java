package com.RegExp.demo.service;

import com.RegExp.demo.entity.Base_Regular_Configuration;

import javax.servlet.http.HttpServletResponse;

public interface ExcelExportService {

    void exportData(Base_Regular_Configuration datalist, HttpServletResponse response);


}
