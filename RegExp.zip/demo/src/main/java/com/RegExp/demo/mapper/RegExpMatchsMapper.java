package com.RegExp.demo.mapper;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RegExpMatchsMapper {

//    int findRegularTotalCount(String siteCode, String regularCode, String codeType, char isCommon, String productionLineCode, String workCellCode);
    int findRegularTotalCount(@Param("baseRegularConfiguration")Base_Regular_Configuration baseRegularConfiguration);

    List<Base_Regular_Configuration> findRegular(@Param("baseRegularConfiguration")Base_Regular_Configuration baseRegularConfiguration,int pageNum,int pageSize);

    int getRepeatRegularTotalCount(String siteCode);
    int getUnionRepeatRegularTotalCount(String siteCode);

    List<Base_Regular_Configuration> getRepeatRegular(String siteCode, int pageNum, int pageSize);

    List<Base_Regular_Configuration> exportRegular(String siteCode, @Param("ids") String[] ids);

    /**
     * 测试类专用
     *
     * @param siteCode
     * @param isCommon
     * @param productionLineCode
     * @param workCellCode
     * @param pageNum
     * @param pageSize
     * @return
     */
    List<Base_Regular_Configuration> findRegularTest(String siteCode, char isCommon, String productionLineCode, String workCellCode, int pageNum, int pageSize);
}
