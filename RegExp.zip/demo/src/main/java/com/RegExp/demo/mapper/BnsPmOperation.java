package com.RegExp.demo.mapper;

import com.RegExp.demo.entity.Bns_Pm_Operation;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BnsPmOperation {
    List<Bns_Pm_Operation> getBarcode(String site_code);

    Boolean validateJYM(String jym, @Param("siteCode") String siteCode);

    void saveCipher(String workuserRandomBarCode,String cipher);
}
