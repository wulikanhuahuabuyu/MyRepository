package com.RegExp.demo.entity;

import java.io.Serializable;
import java.util.Date;

public class Bns_Pm_Operation implements Serializable {
    /**主键**/
    private String id;

    /**订单代码**/
    private String workOrdercode;

    /**工作代码**/
    private String workCode;

    /**型号编码**/
    private String workOperationoutmainitemcode;

    /**型号名称**/
    private String workuserRightmostitemname;

    /**数量**/
    private Long workOperationoutmainitemqty;

    /**主资源**/
    private String workOperationmainrescode;

    /**计划开始时间**/
    private java.util.Date workOperationproductionstartt;

    /**计划结束时间**/
    private java.util.Date workOperationproductionendtim;

    /**节拍**/
    private Long workOperationproductiontime;

    /**生产状态**/
    private String workStatus;

    /**版本**/
    private String workuserSaleversion;

    /**是否已打印条码**/
    private String workuserBarcodeprint;

    /**计划生产小时**/
    private String workuserPlanhour;

    /**计划生产日期**/
    private String workuserPlanday;

    /**生产订单号**/
    private String workuserMordercode;

    /**产品类型**/
    private String workuserItemtype;

    /**条码号**/
    private String workuserBarcode;

    private String workuserRandomBarCode;

    /**条码前码（除去最后四位流水号的条码）**/
    private String workuserFrontbarcode;

    /**日作业合并依据**/
    private String workuserDayordercode;

    /**工厂**/
    private String workuserFactory;

    /**SAP订单类型**/
    private String workuserOrdertype;

    /**单位**/
    private String workuserUnit;

    /**子订单**/
    private String workuserLeftorder;

    /**父订单**/
    private String workuserRightorder;

    /**最末子订单**/
    private String workuserLeftmostorder;

    /**最末父订单**/
    private String workuserRightmostorder;

    /**线体名称**/
    private String workuserLinename;

    /**线体编码**/
    private String workuserLinecode;

    /**实际开始时间**/
    private java.util.Date workResultstarttime;

    /**实际结束时间**/
    private java.util.Date workResultendtime;

    /**是否一次通过 1：是  0：否**/
    private Integer workuserIsftt;

    /**是否已时序拉动**/
    private Integer timeseriesflag;

    /**检验结果**/
    private Integer inspectresult;

    /**客户编码**/
    private String workuserCustomercode;

    /**客户名称**/
    private String workuserCustomerinfo;

    /**电话**/
    private String workuserContacterphone;

    /**联系人**/
    private String workuserContactername;

    /**排产日期**/
    private java.util.Date workuserScheduledate;

    /**客户地址**/
    private String workuserTradecode;

    /**客户城市**/
    private String workuserTradename;

    /**渠道编码**/
    private String workuserChannelcode;

    /**渠道名称**/
    private String workuserChannelname;

    /**积放链**/
    private String jflflag;

    /**成品标识**/
    private String cpflag;

    /**辅料标识**/
    private String flflag;

    /**报工标识**/
    private String dailyworkflag;

    /**T-1计划标识**/
    private String tWms1;

    /**线边库冲减的标示**/
    private String linesideflag;

    /**电商订单号**/
    private String custOrderCode;

    /**电商标识码**/
    private String bank;

    /**默认值图片**/
    private String imagetemp;

    /**状态 1：已入库 2：已发货**/
    private Integer warehousestatus;

    /**显示顺序**/
    private Integer displndex;

    /**描述**/
    private String remark;

    /**可用标识**/
    private Integer active;

    /**数据同步标志**/
    private Integer dateSynFlage;

    /**校验码**/
    private String checkcode;

    /**二维码**/
    private String oid;

    /** 工厂编码 **/
    private String siteCode;

    /** 工厂id **/
    private String siteId;
    /**
     * cas码
     */
    private String casCode;

    private String wifiCode; //wifi码(现用为对应的成品订单号)
    private String cipher; //暗码
    private String exportCode; //外销码
    private String energyURL; //能耗贴
    private String zchStr; //资产编号
    private String selfControlBarcode;// 自制半成品条码
    private String encryptionBarcode;// 加密条码
    private String geAndhide;// 隐藏码和ge码
    private String workUserPressBarCode;//压机条码
    private String semiProdCode;//半成品产品编码
    private String workUserElectronicBarCode;//电控箱体条码
    private String workUserTwoSemiBarCode;//两器半成品条码
    private String workUserElectronicBarCode2;//电控箱体条码
    private String workUserTwoSemiBarCode2;//两器半成品条码
    private String typeCode;
    private String version;
    private String createBy;// 创建人
    private Date createDate;//创建时间

    public String getWorkUserElectronicBarCode() {
        return workUserElectronicBarCode;
    }

    public void setWorkUserElectronicBarCode(String workUserElectronicBarCode) {
        this.workUserElectronicBarCode = workUserElectronicBarCode;
    }

    public String getWorkUserTwoSemiBarCode() {
        return workUserTwoSemiBarCode;
    }

    public void setWorkUserTwoSemiBarCode(String workUserTwoSemiBarCode) {
        this.workUserTwoSemiBarCode = workUserTwoSemiBarCode;
    }

    public String getWorkUserElectronicBarCode2() {
        return workUserElectronicBarCode2;
    }

    public void setWorkUserElectronicBarCode2(String workUserElectronicBarCode2) {
        this.workUserElectronicBarCode2 = workUserElectronicBarCode2;
    }

    public String getWorkUserTwoSemiBarCode2() {
        return workUserTwoSemiBarCode2;
    }

    public void setWorkUserTwoSemiBarCode2(String workUserTwoSemiBarCode2) {
        this.workUserTwoSemiBarCode2 = workUserTwoSemiBarCode2;
    }

    public String getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
    public String getEncryptionBarcode() {
        return encryptionBarcode;
    }

    public void setEncryptionBarcode(String encryptionBarcode) {
        this.encryptionBarcode = encryptionBarcode;
    }

    public String getSelfControlBarcode() {
        return selfControlBarcode;
    }

    public void setSelfControlBarcode(String selfControlBarcode) {
        this.selfControlBarcode = selfControlBarcode;
    }

    public String getWifiCode() {
        return wifiCode;
    }

    public void setWifiCode(String wifiCode) {
        this.wifiCode = wifiCode;
    }

    public String getCipher() {
        return cipher;
    }

    public void setCipher(String cipher) {
        this.cipher = cipher;
    }

    public String getExportCode() {
        return exportCode;
    }

    public void setExportCode(String exportCode) {
        this.exportCode = exportCode;
    }

    public String getEnergyURL() {
        return energyURL;
    }

    public void setEnergyURL(String energyURL) {
        this.energyURL = energyURL;
    }

    public void setId(String id){
        this.id = id == null ? "" : id.trim();
    }

    public String getId(){
        return this.id;
    }

    public void setWorkOrdercode(String workOrdercode){
        this.workOrdercode = workOrdercode == null ? "" : workOrdercode.trim();
    }

    public String getWorkOrdercode(){
        return this.workOrdercode;
    }

    public void setWorkCode(String workCode){
        this.workCode = workCode == null ? "" : workCode.trim();
    }

    public String getWorkCode(){
        return this.workCode;
    }

    public void setWorkOperationoutmainitemcode(String workOperationoutmainitemcode){
        this.workOperationoutmainitemcode = workOperationoutmainitemcode == null ? "" : workOperationoutmainitemcode.trim();
    }

    public String getWorkOperationoutmainitemcode(){
        return this.workOperationoutmainitemcode;
    }

    public void setWorkuserRightmostitemname(String workuserRightmostitemname){
        this.workuserRightmostitemname = workuserRightmostitemname == null ? "" : workuserRightmostitemname.trim();
    }

    public String getWorkuserRightmostitemname(){
        return this.workuserRightmostitemname;
    }

    public void setWorkOperationoutmainitemqty(Long workOperationoutmainitemqty){
        this.workOperationoutmainitemqty = workOperationoutmainitemqty;
    }

    public Long getWorkOperationoutmainitemqty(){
        return this.workOperationoutmainitemqty;
    }

    public void setWorkOperationmainrescode(String workOperationmainrescode){
        this.workOperationmainrescode = workOperationmainrescode == null ? "" : workOperationmainrescode.trim();
    }

    public String getWorkOperationmainrescode(){
        return this.workOperationmainrescode;
    }

    public void setWorkOperationproductionstartt(java.util.Date workOperationproductionstartt){
        this.workOperationproductionstartt = workOperationproductionstartt;
    }

    public java.util.Date getWorkOperationproductionstartt(){
        return this.workOperationproductionstartt;
    }

    public void setWorkOperationproductionendtim(java.util.Date workOperationproductionendtim){
        this.workOperationproductionendtim = workOperationproductionendtim;
    }

    public java.util.Date getWorkOperationproductionendtim(){
        return this.workOperationproductionendtim;
    }

    public void setWorkOperationproductiontime(Long workOperationproductiontime){
        this.workOperationproductiontime = workOperationproductiontime;
    }

    public Long getWorkOperationproductiontime(){
        return this.workOperationproductiontime;
    }

    public void setWorkStatus(String workStatus){
        this.workStatus = workStatus == null ? "" : workStatus.trim();
    }

    public String getWorkStatus(){
        return this.workStatus;
    }

    public void setWorkuserSaleversion(String workuserSaleversion){
        this.workuserSaleversion = workuserSaleversion == null ? "" : workuserSaleversion.trim();
    }

    public String getWorkuserSaleversion(){
        return this.workuserSaleversion;
    }

    public void setWorkuserBarcodeprint(String workuserBarcodeprint){
        this.workuserBarcodeprint = workuserBarcodeprint == null ? "" : workuserBarcodeprint.trim();
    }

    public String getWorkuserBarcodeprint(){
        return this.workuserBarcodeprint;
    }

    public void setWorkuserPlanhour(String workuserPlanhour){
        this.workuserPlanhour = workuserPlanhour == null ? "" : workuserPlanhour.trim();
    }

    public String getWorkuserPlanhour(){
        return this.workuserPlanhour;
    }

    public void setWorkuserPlanday(String workuserPlanday){
        this.workuserPlanday = workuserPlanday == null ? "" : workuserPlanday.trim();
    }

    public String getWorkuserPlanday(){
        return this.workuserPlanday;
    }

    public void setWorkuserMordercode(String workuserMordercode){
        this.workuserMordercode = workuserMordercode == null ? "" : workuserMordercode.trim();
    }

    public String getWorkuserMordercode(){
        return this.workuserMordercode;
    }

    public void setWorkuserItemtype(String workuserItemtype){
        this.workuserItemtype = workuserItemtype == null ? "" : workuserItemtype.trim();
    }

    public String getWorkuserItemtype(){
        return this.workuserItemtype;
    }

    public void setWorkuserBarcode(String workuserBarcode){
        this.workuserBarcode = workuserBarcode == null ? "" : workuserBarcode.trim();
    }

    public String getWorkuserBarcode(){
        return this.workuserBarcode;
    }

    public void setWorkuserFrontbarcode(String workuserFrontbarcode){
        this.workuserFrontbarcode = workuserFrontbarcode == null ? "" : workuserFrontbarcode.trim();
    }

    public String getWorkuserFrontbarcode(){
        return this.workuserFrontbarcode;
    }

    public void setWorkuserDayordercode(String workuserDayordercode){
        this.workuserDayordercode = workuserDayordercode == null ? "" : workuserDayordercode.trim();
    }

    public String getWorkuserDayordercode(){
        return this.workuserDayordercode;
    }

    public void setWorkuserFactory(String workuserFactory){
        this.workuserFactory = workuserFactory == null ? "" : workuserFactory.trim();
    }

    public String getWorkuserFactory(){
        return this.workuserFactory;
    }

    public void setWorkuserOrdertype(String workuserOrdertype){
        this.workuserOrdertype = workuserOrdertype == null ? "" : workuserOrdertype.trim();
    }

    public String getWorkuserOrdertype(){
        return this.workuserOrdertype;
    }

    public void setWorkuserUnit(String workuserUnit){
        this.workuserUnit = workuserUnit == null ? "" : workuserUnit.trim();
    }

    public String getWorkuserUnit(){
        return this.workuserUnit;
    }

    public void setWorkuserLeftorder(String workuserLeftorder){
        this.workuserLeftorder = workuserLeftorder == null ? "" : workuserLeftorder.trim();
    }

    public String getWorkuserLeftorder(){
        return this.workuserLeftorder;
    }

    public void setWorkuserRightorder(String workuserRightorder){
        this.workuserRightorder = workuserRightorder == null ? "" : workuserRightorder.trim();
    }

    public String getWorkuserRightorder(){
        return this.workuserRightorder;
    }

    public void setWorkuserLeftmostorder(String workuserLeftmostorder){
        this.workuserLeftmostorder = workuserLeftmostorder == null ? "" : workuserLeftmostorder.trim();
    }

    public String getWorkuserLeftmostorder(){
        return this.workuserLeftmostorder;
    }

    public void setWorkuserRightmostorder(String workuserRightmostorder){
        this.workuserRightmostorder = workuserRightmostorder == null ? "" : workuserRightmostorder.trim();
    }

    public String getWorkuserRightmostorder(){
        return this.workuserRightmostorder;
    }

    public void setWorkuserLinename(String workuserLinename){
        this.workuserLinename = workuserLinename == null ? "" : workuserLinename.trim();
    }

    public String getWorkuserLinename(){
        return this.workuserLinename;
    }

    public void setWorkuserLinecode(String workuserLinecode){
        this.workuserLinecode = workuserLinecode == null ? "" : workuserLinecode.trim();
    }

    public String getWorkuserLinecode(){
        return this.workuserLinecode;
    }

    public void setWorkResultstarttime(java.util.Date workResultstarttime){
        this.workResultstarttime = workResultstarttime;
    }

    public java.util.Date getWorkResultstarttime(){
        return this.workResultstarttime;
    }

    public void setWorkResultendtime(java.util.Date workResultendtime){
        this.workResultendtime = workResultendtime;
    }

    public java.util.Date getWorkResultendtime(){
        return this.workResultendtime;
    }

    public void setWorkuserIsftt(Integer workuserIsftt){
        this.workuserIsftt = workuserIsftt;
    }

    public Integer getWorkuserIsftt(){
        return this.workuserIsftt;
    }

    public void setTimeseriesflag(Integer timeseriesflag){
        this.timeseriesflag = timeseriesflag;
    }

    public Integer getTimeseriesflag(){
        return this.timeseriesflag;
    }

    public void setInspectresult(Integer inspectresult){
        this.inspectresult = inspectresult;
    }

    public Integer getInspectresult(){
        return this.inspectresult;
    }

    public void setWorkuserCustomercode(String workuserCustomercode){
        this.workuserCustomercode = workuserCustomercode == null ? "" : workuserCustomercode.trim();
    }

    public String getWorkuserCustomercode(){
        return this.workuserCustomercode;
    }

    public void setWorkuserCustomerinfo(String workuserCustomerinfo){
        this.workuserCustomerinfo = workuserCustomerinfo == null ? "" : workuserCustomerinfo.trim();
    }

    public String getWorkuserCustomerinfo(){
        return this.workuserCustomerinfo;
    }

    public void setWorkuserContacterphone(String workuserContacterphone){
        this.workuserContacterphone = workuserContacterphone == null ? "" : workuserContacterphone.trim();
    }

    public String getWorkuserContacterphone(){
        return this.workuserContacterphone;
    }

    public void setWorkuserContactername(String workuserContactername){
        this.workuserContactername = workuserContactername == null ? "" : workuserContactername.trim();
    }

    public String getWorkuserContactername(){
        return this.workuserContactername;
    }

    public void setWorkuserScheduledate(java.util.Date workuserScheduledate){
        this.workuserScheduledate = workuserScheduledate;
    }

    public java.util.Date getWorkuserScheduledate(){
        return this.workuserScheduledate;
    }

    public void setWorkuserTradecode(String workuserTradecode){
        this.workuserTradecode = workuserTradecode == null ? "" : workuserTradecode.trim();
    }

    public String getWorkuserTradecode(){
        return this.workuserTradecode;
    }

    public void setWorkuserTradename(String workuserTradename){
        this.workuserTradename = workuserTradename == null ? "" : workuserTradename.trim();
    }

    public String getWorkuserTradename(){
        return this.workuserTradename;
    }

    public void setWorkuserChannelcode(String workuserChannelcode){
        this.workuserChannelcode = workuserChannelcode == null ? "" : workuserChannelcode.trim();
    }

    public String getWorkuserChannelcode(){
        return this.workuserChannelcode;
    }

    public void setWorkuserChannelname(String workuserChannelname){
        this.workuserChannelname = workuserChannelname == null ? "" : workuserChannelname.trim();
    }

    public String getWorkuserChannelname(){
        return this.workuserChannelname;
    }

    public void setJflflag(String jflflag){
        this.jflflag = jflflag == null ? "" : jflflag.trim();
    }

    public String getJflflag(){
        return this.jflflag;
    }

    public void setCpflag(String cpflag){
        this.cpflag = cpflag == null ? "" : cpflag.trim();
    }

    public String getCpflag(){
        return this.cpflag;
    }

    public void setFlflag(String flflag){
        this.flflag = flflag == null ? "" : flflag.trim();
    }

    public String getFlflag(){
        return this.flflag;
    }

    public void setDailyworkflag(String dailyworkflag){
        this.dailyworkflag = dailyworkflag == null ? "" : dailyworkflag.trim();
    }

    public String getDailyworkflag(){
        return this.dailyworkflag;
    }

    public void setTWms1(String tWms1){
        this.tWms1 = tWms1 == null ? "" : tWms1.trim();
    }

    public String getTWms1(){
        return this.tWms1;
    }

    public void setLinesideflag(String linesideflag){
        this.linesideflag = linesideflag == null ? "" : linesideflag.trim();
    }

    public String getLinesideflag(){
        return this.linesideflag;
    }

    public void setCustOrderCode(String custOrderCode){
        this.custOrderCode = custOrderCode == null ? "" : custOrderCode.trim();
    }

    public String getCustOrderCode(){
        return this.custOrderCode;
    }

    public void setBank(String bank){
        this.bank = bank == null ? "" : bank.trim();
    }

    public String getBank(){
        return this.bank;
    }

    public void setImagetemp(String imagetemp){
        this.imagetemp = imagetemp == null ? "" : imagetemp.trim();
    }

    public String getImagetemp(){
        return this.imagetemp;
    }

    public void setWarehousestatus(Integer warehousestatus){
        this.warehousestatus = warehousestatus;
    }

    public Integer getWarehousestatus(){
        return this.warehousestatus;
    }

    public void setDisplndex(Integer displndex){
        this.displndex = displndex;
    }

    public Integer getDisplndex(){
        return this.displndex;
    }

    public void setRemark(String remark){
        this.remark = remark == null ? "" : remark.trim();
    }

    public String getRemark(){
        return this.remark;
    }

    public void setCreateBy(String createBy){
        this.createBy = createBy == null ? "" : createBy.trim();
    }

    public String getCreateBy(){
        return this.createBy;
    }

//	public void setCreateDate(java.util.Date createDate){
//		this.createDate = createDate;
//	}
//
//	public java.util.Date getCreateDate(){
//		return this.createDate;
//	}
//
//	public void setLastUpdateBy(String lastUpdateBy){
//		this.lastUpdateBy = lastUpdateBy == null ? "" : lastUpdateBy.trim();
//	}
//
//	public String getLastUpdateBy(){
//		return this.lastUpdateBy;
//	}
//
//	public void setLastUpdateDate(java.util.Date lastUpdateDate){
//		this.lastUpdateDate = lastUpdateDate;
//	}
//
//	public java.util.Date getLastUpdateDate(){
//		return this.lastUpdateDate;
//	}

    public void setActive(Integer active){
        this.active = active;
    }

    public Integer getActive(){
        return this.active;
    }

    public void setDateSynFlage(Integer dateSynFlage){
        this.dateSynFlage = dateSynFlage;
    }

    public Integer getDateSynFlage(){
        return this.dateSynFlage;
    }

    public void setCheckcode(String checkcode){
        this.checkcode = checkcode == null ? "" : checkcode.trim();
    }

    public String getCheckcode(){
        return this.checkcode;
    }

    public void setOid(String oid){
        this.oid = oid == null ? "" : oid.trim();
    }

    public String getOid(){
        return this.oid;
    }

    public String getSiteCode() {
        return siteCode;
    }

    public void setSiteCode(String siteCode) {
        this.siteCode = siteCode;
    }

    public String getSiteId() {
        return siteId;
    }

    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }

    public String getWorkuserRandomBarCode() {
        return workuserRandomBarCode;
    }

    public void setWorkuserRandomBarCode(String workuserRandomBarCode) {
        this.workuserRandomBarCode = workuserRandomBarCode;
    }

    public String gettWms1() {
        return tWms1;
    }

    public void settWms1(String tWms1) {
        this.tWms1 = tWms1;
    }

    public String getZchStr() {
        return zchStr;
    }

    public void setZchStr(String zchStr) {
        this.zchStr = zchStr;
    }

    public String getGeAndhide() {
        return geAndhide;
    }

    public void setGeAndhide(String geAndhide) {
        this.geAndhide = geAndhide;
    }
    public String getWorkUserPressBarCode() {
        return workUserPressBarCode;
    }

    public void setWorkUserPressBarCode(String workUserPressBarCode) {
        this.workUserPressBarCode = workUserPressBarCode;
    }

    public String getSemiProdCode() {
        return semiProdCode;
    }

    public void setSemiProdCode(String semiProdCode) {
        this.semiProdCode = semiProdCode;
    }

    public String getCasCode() {
        return casCode;
    }

    public void setCasCode(String casCode) {
        this.casCode = casCode;
    }

    @Override
    public String toString() {
        return "Bns_Pm_Operation{" +
                "id='" + id + '\'' +
                ", workOrdercode='" + workOrdercode + '\'' +
                ", workCode='" + workCode + '\'' +
                ", workOperationoutmainitemcode='" + workOperationoutmainitemcode + '\'' +
                ", workuserRightmostitemname='" + workuserRightmostitemname + '\'' +
                ", workOperationoutmainitemqty=" + workOperationoutmainitemqty +
                ", workOperationmainrescode='" + workOperationmainrescode + '\'' +
                ", workOperationproductionstartt=" + workOperationproductionstartt +
                ", workOperationproductionendtim=" + workOperationproductionendtim +
                ", workOperationproductiontime=" + workOperationproductiontime +
                ", workStatus='" + workStatus + '\'' +
                ", workuserSaleversion='" + workuserSaleversion + '\'' +
                ", workuserBarcodeprint='" + workuserBarcodeprint + '\'' +
                ", workuserPlanhour='" + workuserPlanhour + '\'' +
                ", workuserPlanday='" + workuserPlanday + '\'' +
                ", workuserMordercode='" + workuserMordercode + '\'' +
                ", workuserItemtype='" + workuserItemtype + '\'' +
                ", workuserBarcode='" + workuserBarcode + '\'' +
                ", workuserRandomBarCode='" + workuserRandomBarCode + '\'' +
                ", workuserFrontbarcode='" + workuserFrontbarcode + '\'' +
                ", workuserDayordercode='" + workuserDayordercode + '\'' +
                ", workuserFactory='" + workuserFactory + '\'' +
                ", workuserOrdertype='" + workuserOrdertype + '\'' +
                ", workuserUnit='" + workuserUnit + '\'' +
                ", workuserLeftorder='" + workuserLeftorder + '\'' +
                ", workuserRightorder='" + workuserRightorder + '\'' +
                ", workuserLeftmostorder='" + workuserLeftmostorder + '\'' +
                ", workuserRightmostorder='" + workuserRightmostorder + '\'' +
                ", workuserLinename='" + workuserLinename + '\'' +
                ", workuserLinecode='" + workuserLinecode + '\'' +
                ", workResultstarttime=" + workResultstarttime +
                ", workResultendtime=" + workResultendtime +
                ", workuserIsftt=" + workuserIsftt +
                ", timeseriesflag=" + timeseriesflag +
                ", inspectresult=" + inspectresult +
                ", workuserCustomercode='" + workuserCustomercode + '\'' +
                ", workuserCustomerinfo='" + workuserCustomerinfo + '\'' +
                ", workuserContacterphone='" + workuserContacterphone + '\'' +
                ", workuserContactername='" + workuserContactername + '\'' +
                ", workuserScheduledate=" + workuserScheduledate +
                ", workuserTradecode='" + workuserTradecode + '\'' +
                ", workuserTradename='" + workuserTradename + '\'' +
                ", workuserChannelcode='" + workuserChannelcode + '\'' +
                ", workuserChannelname='" + workuserChannelname + '\'' +
                ", jflflag='" + jflflag + '\'' +
                ", cpflag='" + cpflag + '\'' +
                ", flflag='" + flflag + '\'' +
                ", dailyworkflag='" + dailyworkflag + '\'' +
                ", tWms1='" + tWms1 + '\'' +
                ", linesideflag='" + linesideflag + '\'' +
                ", custOrderCode='" + custOrderCode + '\'' +
                ", bank='" + bank + '\'' +
                ", imagetemp='" + imagetemp + '\'' +
                ", warehousestatus=" + warehousestatus +
                ", displndex=" + displndex +
                ", remark='" + remark + '\'' +
                ", active=" + active +
                ", dateSynFlage=" + dateSynFlage +
                ", checkcode='" + checkcode + '\'' +
                ", oid='" + oid + '\'' +
                ", siteCode='" + siteCode + '\'' +
                ", siteId='" + siteId + '\'' +
                ", casCode='" + casCode + '\'' +
                ", wifiCode='" + wifiCode + '\'' +
                ", cipher='" + cipher + '\'' +
                ", exportCode='" + exportCode + '\'' +
                ", energyURL='" + energyURL + '\'' +
                ", zchStr='" + zchStr + '\'' +
                ", selfControlBarcode='" + selfControlBarcode + '\'' +
                ", encryptionBarcode='" + encryptionBarcode + '\'' +
                ", geAndhide='" + geAndhide + '\'' +
                ", workUserPressBarCode='" + workUserPressBarCode + '\'' +
                ", semiProdCode='" + semiProdCode + '\'' +
                ", workUserElectronicBarCode='" + workUserElectronicBarCode + '\'' +
                ", workUserTwoSemiBarCode='" + workUserTwoSemiBarCode + '\'' +
                ", workUserElectronicBarCode2='" + workUserElectronicBarCode2 + '\'' +
                ", workUserTwoSemiBarCode2='" + workUserTwoSemiBarCode2 + '\'' +
                ", typeCode='" + typeCode + '\'' +
                ", version='" + version + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createDate=" + createDate +
                '}';
    }
}
