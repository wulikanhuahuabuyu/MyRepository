package com.RegExp.demo.service.impl;

import com.RegExp.demo.entity.Base_Regular_Configuration;
import com.RegExp.demo.mapper.RegExpMatchsMapper;
import com.RegExp.demo.service.ExcelExportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import static com.RegExp.demo.util.BrowserDownloadExcel.downloadUnfilledToXlsx;

@Service
public class ExcelExportServiceImpl implements ExcelExportService {

    @Autowired
    RegExpMatchsMapper regExpMatchsMapper;

    @Override
    public void exportData(Base_Regular_Configuration datalist, HttpServletResponse response) {

        String siteCode = datalist.getSiteCode();
        String regularCode = datalist.getRegularCode();
        String codeType = datalist.getCodeType();
        String codeContent = datalist.getCodeContent();
        char isCommon = datalist.getIsCommon();
        String productionLineCode = datalist.getProductionLineCode();
        String workCellCode = datalist.getWorkCellCode();
        String[] ids = datalist.getIds();
        String isFilterRepeat = datalist.getIsFilterRepeat();
        String fileType = datalist.getFileType();
        if (ids.length == 0) {
            ids = new String[]{""};
        }
        List<Base_Regular_Configuration> regLiset = List.of();
        // 获取待导出的数据
        if (!codeContent.isEmpty()) {// 主观件匹配正则
            regLiset = regExpMatchsMapper.exportRegular(siteCode, ids);
        } else {
            if (isFilterRepeat.equals("1")) {//只导出正则编码重复的数据
                regLiset = regExpMatchsMapper.getRepeatRegular(siteCode, 0, 0);
            } else {
                regLiset = regExpMatchsMapper.findRegular(datalist, 0, 0);
            }
        }
//        for (Base_Regular_Configuration item : regLiset) {
////            System.err.println("linedesc>>>>>"+item.getProductionLineName());
//        }

//        // 设置 Excel 文件名和表格名
//        String fileName = "D://test.xlsx";
//       String fname = URLEncoder.encode(fileName, StandardCharsets.UTF_8).replaceAll("\\+", "%20");
////         文件导出到本地
//        EasyExcel.write("D://test.xlsx", Base_Regular_Configuration.class).registerConverter(new CharConverter()).sheet("正则匹配").doWrite(regLiset);
        // 写入数据
        try {
            if (fileType.equals(".xls") || fileType.equals(".xlsx")) {
                downloadUnfilledToXlsx("正则匹配", response, Base_Regular_Configuration.class, regLiset, fileType);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
