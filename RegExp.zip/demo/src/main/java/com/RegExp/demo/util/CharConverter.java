package com.RegExp.demo.util;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.metadata.property.ExcelContentProperty;
import org.springframework.stereotype.Component;

@Component
public class CharConverter implements Converter<Character> {


    /**
     * 开启对 Character 类型的支持
     */
    @Override
    public Class<?> supportJavaTypeKey() {
//        System.err.println("进入了supportJavaTypeKey");
        return Character.class;
    }

    /**
     * 自定义对 Character 类型数据的处理
     */
    @Override
    public WriteCellData<?> convertToExcelData(Character value, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) {
//        System.err.println("进入了convertToExcelData");
//        System.err.println("value:" + value);
        return new WriteCellData<Character>(String.valueOf(value));
    }




}

