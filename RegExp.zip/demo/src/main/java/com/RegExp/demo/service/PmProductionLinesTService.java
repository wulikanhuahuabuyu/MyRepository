package com.RegExp.demo.service;

import com.RegExp.demo.entity.Pm_Production_Lines_t;

import java.util.List;

public interface PmProductionLinesTService {
    List<Pm_Production_Lines_t> findAllLines(String siteCode);

}
