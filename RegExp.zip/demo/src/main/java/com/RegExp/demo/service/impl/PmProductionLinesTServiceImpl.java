package com.RegExp.demo.service.impl;

import com.RegExp.demo.entity.Pm_Production_Lines_t;
import com.RegExp.demo.mapper.PmProductionLinesTMapper;
import com.RegExp.demo.service.PmProductionLinesTService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PmProductionLinesTServiceImpl implements PmProductionLinesTService {
    @Autowired
    PmProductionLinesTMapper pmProductionLinesTMapper;

    @Override
    public List<Pm_Production_Lines_t> findAllLines(String siteCode) {
        return pmProductionLinesTMapper.findAllLines(siteCode);
    }

}
