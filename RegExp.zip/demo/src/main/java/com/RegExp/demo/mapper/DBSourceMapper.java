package com.RegExp.demo.mapper;

import com.RegExp.demo.entity.DB_Info;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
@Mapper
@Repository
public interface DBSourceMapper {
    List<DB_Info> getDB(String siteCode);
    List<DB_Info> getDBCodeName();
}
