var pageNum = 0;
var pageSize = 0;
var prepageSize;
// var currentClickPage = 1;
// var currentPage;
// var nextPage;
// var lastPage;
// 设置id数组，便于查询与导出数据保持一致
let ids = [];

// 根据输入的工厂号来连接对应工厂数据库，进行下一步的主观件正则校验
$(document).ready(function () {
    $('#search-sitecode-btn').click(function () {
        if ($('#search-codeContent-input').val().trim() === '') {
            console.log("$('#search-sitecode-btn').click==================")
            pageNum = 1;
            if (pageSize === 0) {
                pageSize = 0 ? 10 : pageSize;
            }
        }
        // $('.pagination').empty();
        console.log("pageSize============" + pageSize)
        getDataTableList('/list', pageNum, pageSize)

    });

    // ----------------------------导出-----------------------------
    $('.export_type-item').click(function () {
        console.log($(this).text())
        console.log("进入了export_type-item导出")
        var siteCode = $('#search-siteCode-input').val().trim();
        var codeContent = $('#search-codeContent-input').val().trim();
        var isCommon = $('#isCommon-select').val().trim();
        var productionLineCode = $('#search-lineCode-input').val().trim();
        var workCellCode = $('#search-workCellCode-input').val().trim();
        var fileType = $(this).text();
        // 检查表单元素是否为空
        // var rows = $('#dataTable tbody tr');

        if (siteCode === '') {
            warningAlert("请输入工厂号！");
        } else { // 后端导出excel在浏览器下载（导出结果即为页面查询结果）
            var data = {
                siteCode: siteCode,
                codeContent: codeContent,
                isCommon: isCommon,
                productionLineCode: productionLineCode,
                workCellCode: workCellCode,
                ids: ids,
                fileType: fileType
            };

            // 发送Ajax请求到后端，后端返回生成的excel在浏览器自动下载
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/export', true);
            xhr.responseType = 'blob'; // 设置响应类型为 blob
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function () {
                if (xhr.status === 200) {
                    let blob = new Blob();
                    // 创建一个Blob对象
                    if (fileType === '.xlsx') {
                        blob = new Blob([xhr.response], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    }

                    if (fileType === '.xls') {
                        blob = new Blob([xhr.response], {type: 'application/ms-excel;charset=utf-8'});
                    }

                    // 创建一个下载链接
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    if (fileType === '.xls' || fileType === '.xlsx') {
                        a.download = '正则匹配' + fileType; // 设置下载文件的名称
                    }
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    window.URL.revokeObjectURL(url);
                }
            };

            // 发送json数据到后端，后端@RequestBody接收
            xhr.send(JSON.stringify(data));

        }

    });

});


// 双击列表内容自动换行,并自动复制当前单元格内的内容
$("#dataTable").on("dblclick", "td", function () {
    // 自动换行
    $('td').addClass('td-click');

    // 自动复制
    var texts = $(this).text();
    console.log("texts:" + texts)
    if (texts.length === 0) {
        errorAlert("复制失败,文本内容为空!")
        return false;
    }
    var $tempTextarea = $("<textarea>");
    $tempTextarea.val(texts);
    $("body").append($tempTextarea);
    $tempTextarea.select();
    document.execCommand("copy"); // 执行浏览器复制命令
    successAlert("复制成功", 2);
    $tempTextarea.remove();
});

/**
 * 分页处理每页显示条数切换时重新查询并加载表格数据
 * @param pageSizeOption ？条/每页
 */
function pageSizeOptionChange(pageSizeOption) {
    console.log("当前点击了每页条数：" + pageSizeOption)
    pageSize = pageSizeOption;
    $('#pageNumOption-select option[value=" + pageSizeOption + "]').attr('selected', true);
    getDataTableList('/list', pageNum, pageSize);
}

/**
 * 分页处理页码切换时重新查询并加载表格数据
 * @param pageNumOption 页码
 */
// function pageNumOnClick(pageNumOption) {
//     // 上一页
//     if (pageNumOption === '<<') {
//         console.log("currentPage---------------" + currentPage)
//         if (currentPage !== 1) {//非第一页
//             prePage = currentPage - 1;
//             $('.page-item:contains(' + currentPage + ')').removeClass('active');
//             $('.page-item:nth-child(' + (prePage + 2) + ')').addClass('active');
//             getDataTableList('/list', prePage, pageSize);
//         } else if (currentPage === 1) {//第一页，<<不可点击
//             $('#prePageCursor').addClass('cursor-disabled');
//             $('#prePagePionter').addClass('pointer-events-disabled');
//         }
//     }
//
//     // 下一页
//     if (pageNumOption === '>>') {
//         // $('#nextPage').addClass('active');
//         if (nextPage % 10 === 1) {
//             // 页码
//             for (let i = startIdx; i < endIdx; i++) {
//                 $('.pagination').append(
//                     '<li class="page-item item-idx"><a class="page-link" href="#" onclick="pageNumOnClick($(this).text())">' + (i + 1) + '</li>'
//                 );
//                 if (i === 1) {
//                     $('.page-item:nth-child(3)').addClass('active');
//                     $('#prePageCursor').addClass('cursor-disabled');
//                     $('#prePagePionter').addClass('pointer-events-disabled');
//                 }
//             }
//         }
//         if (currentPage !== lastPage) {
//             nextPage = currentPage + 1;
//             $('.page-item:contains(' + currentPage + ')').removeClass('active');
//             $('.page-item:nth-child(' + (nextPage + 2) + ')').addClass('active');
//             $('#prePageCursor').removeClass('cursor-disabled');
//             $('#prePagePionter').removeClass('pointer-events-disabled');
//             getDataTableList('/list', nextPage, pageSize);
//
//         }
//     } else {
//         // $('#nextPage').removeClass('active');
//         $('.page-item:contains(' + currentPage + ')').removeClass('active');
//         $('#prePageCursor').removeClass('cursor-disabled');
//         $('#prePagePionter').removeClass('pointer-events-disabled');
//     }
//     console.log("currentPage//////////////////////" + currentPage);
//     if (pageNumOption !== '<<' && pageNumOption !== '>>') {
//         console.log(1111111111111111111111111111111111111111111111111)
//         // // 前进/后退设置鼠标禁用样式+事件，当前页码首页则<<不可点击，当前页码最后一页则>>不可点击
//         if (currentPage === 1) {
//             $('#prePageCursor').addClass('cursor-disabled');
//             $('#prePagePionter').addClass('pointer-events-disabled');
//         } else {
//             $('#prePageCursor').removeClass('cursor-disabled');
//             $('#prePagePionter').removeClass('pointer-events-disabled');
//         }
//         currentPage = pageNumOption;
//         // 选中页码(nthChildSort)未切换时永久活跃，+2：共？条、<<
//         const nthChildSort = Number(currentPage) + 2;
//         $('.page-item:contains(' + currentPage + ')').removeClass('active');
//         $('.page-item:nth-child(' + nthChildSort + ')').addClass('active');
//         console.log("pageSize>>>>" + pageSize)
//         console.log("prePage>>>>" + prePage)
//         console.log("currentPage>>>>" + currentPage)
//         console.log("nextPage>>>>" + nextPage)
//         console.log("lastPage>>>>" + lastPage)
//
//         getDataTableList('/list', currentPage, pageSize);
//     }
//
// }

/**
 * 控制【是否共用】显示/隐藏线体、站点
 * @param isCommonOption 是否共用选项：共用/不共用
 */
function isCommonOptionChange(isCommonOption) {
    // alert(option);
    if (isCommonOption === "是") {
        $('#line_workCell_code-display').addClass('show_or_hide');
        $('#search-lineCode-input').addClass('no_dit').val('').attr('placeholder', '禁止输入');
        $('#search-workCellCode-input').addClass('no_dit').val('').attr('placeholder', '禁止输入');
    } else {
        $('#line_workCell_code-display').removeClass('show_or_hide');
        $('#search-lineCode-input').removeClass('no_dit').val('').attr('placeholder', '请输入线体编码..');
        $('#search-workCellCode-input').removeClass('no_dit').val('').attr('placeholder', '请输入站点编码..');
    }
}

// 全局设置加载动画显示/隐藏,查询中显示,查询成功后隐藏
$(function () {
    $.ajaxSetup({
        beforeSend: function () {
            //ajax请求之前,展示加载中动画
            $('.col-md-3').css('display', 'flow');
            console.log('ajaxBefore')
        },
        error: function (error) {
            //ajax请求失败
            console.error('Error:', error);
            console.log('ajaxError');
        },
        complete: function () {
            //ajax请求完成，不管成功失败,关闭加载中动画
            $('.col-md-3').css('display', 'none');
            console.log('ajaxComlete')
        }
    });
})

/**
 * 自定义消息提示框
 * @param message 提示信息
 * @param time 弹窗几秒消失
 * @param params 自定义样式
 */
function myAlert(message, time, params) {
    let width = 260;
    let height = 50;
    let color = "#FFF";
    let backgroundColor = "rgba(6,9,38,0.9)";
    let fontWeight = "normal";
    let opacity = "0.6";
    // console.log(isNaN(Number(time)))
    if (!time || isNaN(Number(time))) {
        //默认值，2.5s
        time = 2500;
    }

    //获取顶级窗口,设置弹窗块级区域
    let bodyEle = window.top.document.body;
    let divELe = document.createElement("div");

    //实现CSS多样化,自定义赋值
    divELe.className = 'myAlert';
    divELe.style.width = width + 'px';
    divELe.style.height = height + 'px';
    divELe.style.position = 'fixed';
    divELe.style.top = '0px';
    divELe.style.left = '50%';
    divELe.style.marginLeft = -width / 2 + 'px';
    divELe.style.marginTop = '10px';
    divELe.style.color = color;
    divELe.style.backgroundColor = backgroundColor;
    divELe.style.textAlign = "center";
    divELe.style.lineHeight = height + "px";
    divELe.style.fontSize = "15px";
    divELe.style.border = "0px";
    divELe.style.borderRadius = "5px";
    divELe.style.opacity = opacity;
    divELe.style.fontWeight = fontWeight;
    divELe.style.display = "none";

    //设置给定参数,实现CSS多样化,自定义赋值
    if (params && params instanceof Object) {
        for (let item in params) {
            divELe.style[item] = params[item];
            if (item == 'width') {
                let width = params[item].substring(0, params[item].length - 2)
                divELe.style.marginLeft = -width / 2 + 'px';
            }
            if (item === 'height') {
                divELe.style.lineHeight = params[item];
            }
        }
    }
    divELe.innerText = message;
    bodyEle.appendChild(divELe);
    $(".myAlert").slideDown(200, () => {
        setTimeout(() => {
            $(".myAlert").slideUp(200, () => {
                $(".myAlert").remove();
            })
        }, time)

    });
}

// 成功
function successAlert(message, time) {
    myAlert(message, time, {color: '#00FF00'})
}

// 失败
function errorAlert(message, time) {
    myAlert(message, time, {backgroundColor: '#FF0000', fontWeight: 'bold', color: '#000', opacity: '1'})
}

// 警告
function warningAlert(message, time) {
    myAlert(message, time, {color: '#FFA500'})
}

/**
 * 查询接口封装
 * @param url 接口地址
 * @param pageNum 页码
 * @param pageSize 条/页
 */
function getDataTableList(url, pageNum, pageSize) {
    console.log("pageSize》》》》》" + pageSize)
    var siteCode = $('#search-siteCode-input').val().trim();
    var codeContent = $('#search-codeContent-input').val().trim();
    var isCommon = $('#isCommon-select').val().trim();
    var productionLineCode = $('#search-lineCode-input').val().trim();
    var workCellCode = $('#search-workCellCode-input').val().trim();
    if (siteCode === '') {
        warningAlert("请输入工厂号！")
    }
    if (siteCode !== '' && isCommon !== '') {
        console.log('pageSize>>>>' + pageSize)
        // 每次查询时，清空之前的搜索结果
        $('#dataTable').empty();
        $.ajax({
            url: url,
            method: 'GET',
            contentType: 'application/json',
            dataType: 'json',
            data: {
                "siteCode": siteCode,
                "regularCode":"",
                "codeContent": codeContent,
                "isCommon": isCommon,
                "productionLineCode": productionLineCode,
                "workCellCode": workCellCode,
                // 暂时定义,分页查询
                "pageNum": pageNum,
                "pageSize": pageSize
            },
            success: function (data) {
                ids.splice(0, ids.length); //每次查询后清空ids数组，使数组保持最新
                if (data.state === 300) {
                    // 连接错误
                    $('#dataTable').append('<tr></tr><td style="text-align: left;white-space: wrap">' + '<h2>查询失败：</h2>' + data.message + '</td></tr>')
                }

                if (data.state === 400) {
                    // 无工厂数据库链接
                    $('#dataTable').append('<h2 style="text-align: center">' + data.message + '</h2>')
                }
                if (data.state === 204 && data.data.dataList.length === 0 && codeContent !== '') {
                    // 查询结果为空，无匹配正则
                    $('#dataTable').append('<h2 style="text-align: center">' + data.message + ',无匹配正则</h2>')
                }
                if (data.state === 204 && data.data.dataList.length === 0 && codeContent === '' && productionLineCode === '' && workCellCode === '') {
                    // 查询结果为空
                    $('#dataTable').append('<h2 style="text-align: center">' + data.message + '</h2>')
                }
                if (data.state == 200 && data.data.dataList.length !== 0) {
                    // 查询成功
                    $('#dataTable').append(
                        '<thead>' +
                        '<th>序号</th>' +
                        '<th>工厂号</th>' +
                        '<th>正则编码</th>' +
                        '<th>正则码</th>' +
                        '<th>正则名称</th>' +
                        '<th>正则内容</th>' +
                        '<th>是否共用</th>' +
                        '<th>线体编码</th>' +
                        '<th>线体名称</th>' +
                        '<th>工位编码</th>' +
                        '<th>工位名称</th>' +
                        '<th>创建人</th>' +
                        '<th>创建时间</th>' +
                        '<th>修改人</th>' +
                        '<th>修改时间</th>' +
                        '</thead>'
                    )
                }
                if (data.data.dataList !== null) {
                    data.data.dataList.forEach((item, i) => {//表格列赋值，设置内边距，文本居中
                        $('#dataTable').append(
                            '<tr>' +
                            '<td>' + (i + 1) + '</td>' +
                            '<td style="text-align: center !important;">' + siteCode + '</td>' +
                            '<td style="padding-left: 5px !important;">' + item.regularCode + '</td>' +
                            '<td style="padding-left: 5px !important;">' + item.codeType + '</td>' +
                            '<td style="padding-left: 5px !important;">' + item.barCode + '</td>' +
                            '<td style="padding-left: 5px !important;">' + item.regularContent + '</td>' +
                            '<td style="text-align: center !important;">' + item.isCommon + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.productionLineCode == null ? "" : item.productionLineCode) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.productionLineName == null ? "" : item.productionLineName) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.workCellCode == null ? "" : item.workCellCode) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.workCellName == null ? "" : item.workCellName) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.createBy == null ? "" : item.createBy) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.createDate == null ? "" : item.createDate) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.lastUpdateBy == null ? "" : item.lastUpdateBy) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.lastUpdateDate == null ? "" : item.lastUpdateDate) + '</td>' +
                            '</tr>'
                        );
                        ids.push(item.id);
                        // console.log("itemid>"+ids)
                    });
                    /**
                     * 分页功能，根据每页显示条数自动计算添加页码~~~~~~~~~~~~~~~~~~~~~待实现
                     */
                    // prePage = data.data.prePage;
                    // currentPage = data.data.currentPage;
                    // nextPage = data.data.nextPage;
                    lastPage = data.data.totalPage;
                    prepageSize = pageSize;
                    pageSize = data.data.pageSize;
                    console.log("pageSize>>>+___________" + pageSize)

                    if (prepageSize !== pageSize) {
                        $(".pagination").paginate({
                            count: lastPage,
                            start: 1,
                            display: 7,
                            border: true,
                            border_color: '#fff',
                            text_color: '#fff',
                            background_color: 'black',
                            border_hover_color: '#ccc',
                            text_hover_color: '#000',
                            background_hover_color: '#fff',
                            images: false,
                            mouse: 'press',
                            onChange: function (page) {
                                getDataTableList('/list', page, pageSize)
                            }
                        });
                    }

                    //共？条 <<
                    $('.pagination,.jPaginate').prepend(
                        '<span class="page-link">共' + data.data.totalCount + '条</span>'
                    );

                    // 条/页 >> // class="page-link"
                    $('.pageSize').replaceWith(
                        '<li class="page-item">' +// <a class="page-link" style="margin-right: 15px;" href="#" onclick="pageNumOnClick($(this).text())">>></a></li>
                        '<select name="pageNumOption" id="pageNumOption-select" onchange="pageSizeOptionChange(this.options[this.options.selectedIndex].value)">' +
                        '   <option value="10">10条/页</option>' +
                        '   <option value="20">20条/页</option>' +
                        '   <option value="50">50条/页</option>' +
                        '   <option value="100">100条/页</option>' +
                        '   <option value="500">500条/页</option>' +
                        '   <option value="1000">1000条/页</option>' +
                        '   <option value="' + data.data.totalCount + '">最大</option>' +
                        '</select>'
                    );


                }

                /**
                 * **********👇表格样式、功能具体化👇**********
                 */
                // 列宽自由调整
                $("#dataTable").colResizable({
                    // disable: true,//每次加载数据前先禁用插件,然后重新启用插件,否则会不生效
                    liveDrag: true,//实现实时拖动，可看见拖动轨迹
                    draggingClass: "dragging", //防止拖动出险虚标线
                });

                // 实现行上下移动
                $(function () {
                    $("tbody").sortable({
                        revert: true,
                        opactity: 0.6
                    });
                    $("tbody").draggable({
                        connectToSortable: "tr",
                        helper: "clone",
                        // helper: function() {
                        //     let helper = $(this).clone();
                        //     helper.css({'opacity': '0.6', 'background': 'blue'}); // 设置clone元素的样式
                        //     return helper;
                        // },
                        revert: "invalid"

                    });
                    $("tbody,tr").disableSelection();
                });

                /**
                 * **********👆表格样式、功能具体化👆**********
                 */

            },
            error: function (xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }
}