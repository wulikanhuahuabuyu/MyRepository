var xhr = new XMLHttpRequest();
var pageNum = 1;
var pageSize = 0;
var lastPage;
var prepageSize;
// 设置id数组，便于查询与导出数据保持一致
let ids = [];
$(document).ready(function () {
    // let siteCode = $('#search-siteCode-input').val().split('-')[0];
    getSiteCodeList();
    /*
    切换工厂，线体也随之切换对应工厂下的线体列表
     */
    $("#search-siteCode-input").on("change", function () {
        siteCode = $('#search-siteCode-input').val().split('-')[0];
        // input value rest
        restInputText($(this));
        if (siteCode !== '' /*&& $('#isCommon-select').val() ==='0'*/) {
            console.log("**********************************")/**/
            // 获取线体列表
            $('#search-lineCode-input,#search-workCellCode-input').val('').attr('placeholder', '')
            getlineList(siteCode);
        }

    });

    /**
     * 工厂下拉列表
     */
    $("#search-siteCode-input").click(function () {
        if ($('#siteCodeList').html() === '') {
            getSiteCodeList();
        }
    })

    /*
    切换线体，工位也随之切换对应线体下的工位列表
     */
    $('#search-lineCode-input').on("change", function () {
        restInputText($(this));
        let siteCode = $('#search-siteCode-input').val().split('-')[0];
        let lineVal = $('#search-lineCode-input').val();
        let productionlineId = $('#lineList option[value=' + lineVal + ']').attr('id');
        if (siteCode !== '' && lineVal !== '') {
            // 获取工厂线体工位列表
            $('#search-workCellCode-input').val('').attr('placeholder', '')
            getCellList(siteCode, productionlineId);
        }
    })

    $('#search-workCellCode-input').on("change", function () {
        restInputText($(this));
    })


    // 查询（正则校验）
    $('#search-sitecode-btn').click(function () {
        getDataTableList('/list', pageNum, pageSize)
    });

    // 输入框鼠标移入移出
    $('input').hover(function () {
        const this_ = this;
        const id = document.getElementById(this.id);
        const id_arr = ['search-codeContent-input', 'search-regularCode-input', 'search-codeType-input','search-regContent-input'];
        if (!id_arr.includes(this_.id)) {
            id.onmouseover = function () {
                if ($(this_).val() !== '') {
                    $(this_).val('')
                    this_.placeholder = this_.textContent;
                }
                // $(this).siblings('.iconclear').css('visibility', 'visible')
            }
            id.onmouseout = function () {
                $(this_).val(this.placeholder)
                this_.textContent = $(this_).val()
                // $(this).siblings('.iconclear').css('visibility', 'hidden')
            }
        }

    })

    //icon 清除
    // $('.iconclear').click(function () {
    //     console.log(".iconclear').click(function (---------------")
    //     $(this).prev().val('')
    // })

    /**
     * 导出
     */
    $('.export_type-item').click(function () {
        console.log("进入了export_type-item导出")
        var siteCode = $('#search-siteCode-input').val().trim().split('-')[0];
        var codeContent = $('#search-codeContent-input').val().trim();
        var isCommon = $('#isCommon-select').val().trim();
        var productionLineCode = $('#search-lineCode-input').val().trim();
        var workCellCode = $('#search-workCellCode-input').val().trim();
        var fileType = $(this).text();
        // 检查表单元素是否为空
        // var rows = $('#dataTable tbody tr');

        if (siteCode === '') {
            warningAlert("请输入工厂号！");
        } else { // 后端导出excel在浏览器下载（导出结果即为页面查询结果）
            console.log("ids>>>>>>>>>"+ids)
            var data = {
                siteCode: siteCode,
                codeContent: codeContent,
                isCommon: isCommon,
                productionLineCode: productionLineCode,
                workCellCode: workCellCode,
                ids: ids,
                isFilterRepeat: $('#isRegularRepeat-select').val(),
                fileType: fileType
            };

            // 发送Ajax请求到后端，后端返回生成的excel在浏览器自动下载
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/export', true);
            xhr.responseType = 'blob'; // 设置响应类型为 blob
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = function () {
                if (xhr.status === 200) {
                    let blob = new Blob();
                    // 创建一个Blob对象
                    if (fileType === '.xlsx') {
                        blob = new Blob([xhr.response], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
                    }

                    if (fileType === '.xls') {
                        blob = new Blob([xhr.response], {type: 'application/ms-excel;charset=utf-8'});
                    }

                    // 创建一个下载链接
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    if (fileType === '.xls' || fileType === '.xlsx') {
                        a.download = '正则匹配' + fileType; // 设置下载文件的名称
                    }
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    window.URL.revokeObjectURL(url);
                }
            };

            // 发送json数据到后端，后端@RequestBody接收
            xhr.send(JSON.stringify(data));

        }

    });

});

// 输入框监听回车事件
$('input').each(function () {
    this.addEventListener('keyup', function (event) {
        if (event.keyCode === 13) {
            event.preventDefault();
            $('#search-sitecode-btn').click();
        }
    })
})

/**
 * 内容重置init
 */
function restInputText(this_) {
    const selectSiteCodeOption = this_.val();
    for (let i = 0; i < $('option').length; i++) {
        if (selectSiteCodeOption === $('option').eq(i).val()) {
            this_.val(selectSiteCodeOption);
            this_.text(selectSiteCodeOption);
            break;
        } else {
            this_.val('');
        }
    }
    if ($('#search-siteCode-input').val().trim() === '') {
        $('#search-lineCode-input').val('')
        $('#search-workCellCode-input').val('')
    } else if ($('#search-lineCode-input').val().trim() === '') {
        $('#search-workCellCode-input').val('')
    }
}

// 双击列表内容自动换行,并自动复制当前单元格内的内容
$("#dataTable").on("dblclick", "td", function () {
    // 自动换行
    $('td').addClass('td-click');

    // 自动复制
    const texts = $(this).text();
    console.log("texts:" + texts)
    if (texts.length === 0) {
        errorAlert("复制失败,文本内容为空!")
        return false;
    }
    const $tempTextarea = $("<textarea>");
    $tempTextarea.val(texts);
    $("body").append($tempTextarea);
    $tempTextarea.select();
    document.execCommand("copy"); // 执行浏览器复制命令
    successAlert("复制成功", 2);
    $tempTextarea.remove();
});

/**
 * 分页处理每页显示条数切换时重新查询并加载表格数据
 * @param pageSizeOption ？条/每页
 */
function pageSizeOptionChange(pageSizeOption) {
    console.log("当前点击了每页条数：" + pageSizeOption)
    pageSize = pageSizeOption;
    $('#pageNumOption-select option[value=" + pageSizeOption + "]').attr('selected', true);
    getDataTableList('/list', pageNum, pageSize);
}

/**
 * 控制【是否共用】显示/隐藏线体、站点
 * @param isCommonOption 是否共用选项：共用/不共用
 */
function isCommonOptionChange(isCommonOption) {
    // alert($('#search-siteCode-input').val().trim().split('-')[0]);
    if (isCommonOption === "是") {
        $('#line_workCell_code-display').addClass('cursor-disabled');
        $('#search-lineCode-input').addClass('no_dit').val('').attr('placeholder', '');
        $('#search-workCellCode-input').addClass('no_dit').val('').attr('placeholder', '');
    } else {
        $('#line_workCell_code-display').removeClass('cursor-disabled');
        $('#search-lineCode-input').removeClass('no_dit').val('');
        $('#search-workCellCode-input').removeClass('no_dit').val('');

    }
}

// 全局设置加载动画显示/隐藏,查询中显示,查询成功后隐藏
$(function () {
    $.ajaxSetup({
        beforeSend: function () {
            //ajax请求之前,展示加载中动画
            $('.col-md-3').css('display', 'flow');
            console.log('ajaxBefore')
        },
        error: function (error) {
            //ajax请求失败
            console.error('Error:', error);
            console.log('ajaxError');
        },
        complete: function () {
            //ajax请求完成，不管成功失败,关闭加载中动画
            $('.col-md-3').css('display', 'none');
            console.log('ajaxComlete')
        }
    });
})


/**
 * 查询/校验正则接口封装
 * @param url 接口地址
 * @param pageNum 页码
 * @param pageSize 条/页
 */
function getDataTableList(url, pageNum, pageSize) {
    let siteCode = $('#search-siteCode-input').val().split('-')[0];
    let regularCode = $('#search-regularCode-input').val().trim();
    let codeType = $('#search-codeType-input').val().trim();
    let codeContent = $('#search-codeContent-input').val().trim();
    let isCommon = $('#isCommon-select').val();
    let productionLineCode = $('#search-lineCode-input').val().split('-')[0];
    let workCellCode = $('#search-workCellCode-input').val().split('-')[0];
    let regularContent = $('#search-regContent-input').val().trim();

    if (siteCode === '') {
        warningAlert("请输入工厂号！")
    }
    if (siteCode !== '' && isCommon !== '') {
        prepageSize = pageSize;
        if (codeContent !== '') {
            pageSize = 0;
            $('#codeContent').css({
                'background-color': '#EDF2FA',
                'border-radius': '3px',
                'border-width': '10px',
                'padding': '5px',
                'border': '2px outset #D3E3FD',
                'box-shadow': '0 0 0 2px skyblue',
                'display': 'block'
            });
            if ($('#codeContent').html() !== '') {
                $('#codeContent text').replaceWith('<text><b>主观件内容：</b>' + codeContent + '</text>');
                if ($('#isRegularCheck-select option:selected').text() === '否') {
                    $('#codeContent').empty();
                }
            } else {
                $('#codeContent').append('<text><b>主观件内容：</b>' + codeContent + '</text>');
            }

        } else {
            pageSize = pageSize === 0 ? 10 : pageSize;
            $('#codeContent text').empty()
            $('#codeContent').css('display', 'none');
        }
        // 每次查询时，清空之前的搜索结果
        $('#dataTable').empty();
        console.log($('#isRegularCheck-select option:selected').text())

        // let dataList = {
        //     "siteCode": siteCode,
        //     "regularCode": regularCode,
        //     "codeType": codeType,
        //     "codeContent": $('#isRegularCheck-select option:selected').text() === '否' ? '' : codeContent,
        //     "isCommon": isCommon,
        //     "productionLineCode": productionLineCode,
        //     "workCellCode": workCellCode,
        //     // 暂时定义,分页查询
        //     "pageNum": pageNum,
        //     "pageSize": pageSize
        // };
        //
        // if (url === '/selectRepeatRegular') {
        //     dataList = {
        //         "siteCode": siteCode,
        //         "pageNum": pageNum,
        //         "pageSize": pageSize
        //     }
        // }

        xhr = $.ajax({
            url: url,
            method: 'GET',
            contentType: 'application/json',
            dataType: 'json',
            data: {
                "siteCode": siteCode,
                "regularCode": regularCode,
                "codeType": codeType,
                "codeContent": $('#isRegularCheck-select option:selected').text() === '否' ? '' : codeContent,
                "isCommon": isCommon,
                "productionLineCode": productionLineCode,
                "workCellCode": workCellCode,
                "isFilterRepeat": $("#isRegularRepeat-select option:selected").val(),
                "regularContent":regularContent,
                "pageNum": pageNum,
                "pageSize": pageSize
            },
            success: function (data) {
                ids.splice(0, ids.length); //每次查询后清空ids数组，使数组保持最新
                if (data.state === 300) {
                    // 连接错误
                    $('#dataTable').append('<tr></tr><td style="text-align: left;white-space: wrap">' + '<h2>查询失败：</h2>' + data.message + '</td></tr>')
                    $('.pageSize-li').empty()
                }

                if (data.state === 400) {
                    // 无工厂数据库链接
                    $('#dataTable').append('<h2 style="text-align: center">' + data.message + '</h2>')
                }
                if (data.state === 204) {
                    // 查询结果为空
                    $('#dataTable').append('<h2 style="text-align: center">' + data.message + '</h2>')
                }
                if (data.state == 200 && data.data.dataList.length !== 0) {
                    // 查询成功
                    $('#dataTable').append(
                        '<thead>' +
                        '<th>序号</th>' +
                        '<th>工厂号</th>' +
                        '<th>正则编码</th>' +
                        '<th>正则码</th>' +
                        '<th>正则名称</th>' +
                        '<th>正则内容</th>' +
                        '<th>是否共用</th>' +
                        '<th>是否DB验证</th>' +
                        '<th>线体编码</th>' +
                        '<th>线体名称</th>' +
                        '<th>工位编码</th>' +
                        '<th>工位名称</th>' +
                        '<th>创建人</th>' +
                        '<th>创建时间</th>' +
                        '<th>修改人</th>' +
                        '<th>修改时间</th>' +
                        '</thead>'
                    )
                }
                if (data.data.dataList !== null) {
                    data.data.dataList.forEach((item, i) => {//表格列赋值，设置内边距，文本居中
                        $('#dataTable').append(
                            '<tr>' +
                            '<td>' + (i + 1) + '</td>' +
                            '<td style="text-align: center !important;">' + siteCode + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.regularCode == null ? "" : item.regularCode) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.codeType == null ? "" : item.codeType) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.barCode == null ? "" : item.barCode) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.regularContent == null ? "" : item.regularContent) + '</td>' +
                            '<td style="text-align: center !important;">' + item.isCommon + '</td>' +
                            '<td style="text-align: center !important;">' + item.isCheck + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.productionLineCode == null ? "" : item.productionLineCode) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.productionLineName == null ? "" : item.productionLineName) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.workCellCode == null ? "" : item.workCellCode) + '</td>' +
                            '<td style="padding-left: 5px !important;">' + (item.workCellName == null ? "" : item.workCellName) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.createBy == null ? "" : item.createBy) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.createDate == null ? "" : item.createDate) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.lastUpdateBy == null ? "" : item.lastUpdateBy) + '</td>' +
                            '<td style="text-align: center !important;">' + (item.lastUpdateDate == null ? "" : item.lastUpdateDate) + '</td>' +
                            '</tr>'
                        );
                        ids.push(item.id);
                    });

                    if (data.data.errDataList.length !== 0) {
                        $('#dataTable').append(
                            '<tr>' +
                            '<td class="errRegular" colspan="15"><text class="iconfont iconhand_below"/>格式有误的正则<text class="iconfont iconhand_below"/></td>' +
                            '</tr>'
                        )
                        if (data.data.errDataList !== null) {
                            data.data.errDataList.forEach((item, i) => {//表格列赋值，设置内边距，文本居中
                                $('#dataTable').append(
                                    '<tr style="background-color: #f18d07 !important;">' +
                                    '<td>' + (i + 1) + '</td>' +
                                    '<td style="text-align: center !important;">' + siteCode + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.regularCode == null ? "" : item.regularCode) + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.codeType == null ? "" : item.codeType) + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.barCode == null ? "" : item.barCode) + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.regularContent == null ? "" : item.regularContent) + '</td>' +
                                    '<td style="text-align: center !important;">' + item.isCommon + '</td>' +
                                    '<td style="text-align: center !important;">' + item.isCheck + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.productionLineCode == null ? "" : item.productionLineCode) + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.productionLineName == null ? "" : item.productionLineName) + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.workCellCode == null ? "" : item.workCellCode) + '</td>' +
                                    '<td style="padding-left: 5px !important;">' + (item.workCellName == null ? "" : item.workCellName) + '</td>' +
                                    '<td style="text-align: center !important;">' + (item.createBy == null ? "" : item.createBy) + '</td>' +
                                    '<td style="text-align: center !important;">' + (item.createDate == null ? "" : item.createDate) + '</td>' +
                                    '<td style="text-align: center !important;">' + (item.lastUpdateBy == null ? "" : item.lastUpdateBy) + '</td>' +
                                    '<td style="text-align: center !important;">' + (item.lastUpdateDate == null ? "" : item.lastUpdateDate) + '</td>' +
                                    '</tr>'
                                );
                                // 格式有误的正则暂时不需要导出
                                // ids.push(item.id);
                            });
                        }
                    }

                    /**
                     * 分页功能，根据每页显示条数自动计算添加页码
                     */
                    lastPage = data.data.totalPage;
                    pageSize = data.data.pageSize;

                    if (prepageSize !== pageSize) {
                        $(".pagination").paginate({
                            count: lastPage,
                            start: 1,
                            display: 7,
                            border: true,
                            border_color: '#fff',
                            text_color: '#fff',
                            background_color: 'cornflowerblue',
                            border_hover_color: '#ccc',
                            text_hover_color: '#000',
                            background_hover_color: '#fff',
                            images: false,
                            mouse: 'press',
                            onChange: function (page) {
                                console.log("pageSize>>>>>" + pageSize)
                                getDataTableList(url, page, pageSize);
                            }
                        });
                    }

                    //共？条 <<
                    $('.resultCount').empty();
                    var unionCount = $('#isRegularRepeat-select').val();
                    $('.resultCount').prepend(
                        '<div class="page-link">共' + data.data.totalCount + '条'+(unionCount==='1'?'（重复数:'+(data.data.unionRepeatTotalCount):'）')+'</div>'
                    );

                    // 条/页 >> // class="page-link"
                    $('.pageSize').replaceWith(
                        '<li class="page-item">' +// <a class="page-link" style="margin-right: 15px;" href="#" onclick="pageNumOnClick($(this).text())">>></a></li>
                        '<select style="background-color: cornflowerblue !important; height: 24px !important;" name="pageNumOption" id="pageNumOption-select" onchange="pageSizeOptionChange(this.options[this.options.selectedIndex].value)">' +
                        '   <option value="10">10条/页</option>' +
                        '   <option value="20">20条/页</option>' +
                        '   <option value="50">50条/页</option>' +
                        '   <option value="100">100条/页</option>' +
                        '   <option value="500">500条/页</option>' +
                        '   <option value="1000">1000条/页</option>' +
                        '   <option value="' + data.data.totalCount + '">最大</option>' +
                        '</select>'
                    );


                }

                /**
                 * **********👇表格样式、功能具体化👇**********
                 */
                // 列宽自由调整
                $("#dataTable").colResizable({
                    // disable: true,//每次加载数据前先禁用插件,然后重新启用插件,否则会不生效
                    liveDrag: true,//实现实时拖动，可看见拖动轨迹
                    draggingClass: "dragging", //防止拖动出险虚标线
                });

                // 实现行上下移动
                $(function () {
                    $("tbody").sortable({
                        revert: true,
                        opactity: 0.6
                    });
                    $("tbody").draggable({
                        connectToSortable: "tr",
                        helper: "clone",
                        // helper: function() {
                        //     let helper = $(this).clone();
                        //     helper.css({'opacity': '0.6', 'background': 'blue'}); // 设置clone元素的样式
                        //     return helper;
                        // },
                        revert: "invalid"

                    });
                    $("tbody,tr").disableSelection();
                });

                /**
                 * **********👆表格样式、功能具体化👆**********
                 */

            },
            error: function (xhr, status, error) {
                console.error('Error:', error);
            }
        });
    }
}

/**
 * 获取工厂下拉列表
 */
function getSiteCodeList() {
    let siteCode = $('#search-siteCode-input').val().split('-')[0];
    // 获取工厂号
    xhr = $.ajax({
        url: '/getDB',
        method: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        data: {
            "siteCode": siteCode
        },
        success: function (data) {
            if (data.state === 200 && data.data.length > 0) {
                for (let i = 0; i < data.data.length; i++) {
                    $('#siteCodeList').append('<option value=' + data.data[i].siteCode + "-" + data.data[i].siteName + '></option>');
                }
            }

        },
        error: function (xhr, status, error) {
            console.error('Error:', error);
        }
    });
}

/**
 * 获取工厂线体下拉列表
 */
function getlineList(siteCode) {
    xhr = $.ajax({
        url: '/getlineList',
        method: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        data: {
            "siteCode": siteCode
        },
        success: function (data) {
            $('#lineList,#cellList').empty();
            data.data.forEach(function (item, index) {
                $('#lineList').append('<option id=' + item.productionLineId + ' ' + 'value=' + item.productionLineCode + '-' + item.productionLineDesc + ' />');
            })
        },
        error: function (xhr, status, error) {
            $('#lineList,#cellList').empty();
        }
    })
}

/**
 * 获取工厂+线体下工位列表
 */
function getCellList(siteCode, productionlineId) {
    xhr = $.ajax({
        url: '/getCellList',
        method: 'GET',
        contentType: 'application/json',
        dataType: 'json',
        data: {
            "siteCode": siteCode,
            "productionlineId": productionlineId
        },
        success: function (data) {
            $('#cellList').empty();
            console.log("data>>>>" + data.data.length)
            data.data.forEach(function (item, index) {
                $('#cellList').append('<option value=' + item.workCellCode + '-' + item.workCellDesc + ' />');
            })
        },
        error: function (xhr, status, error) {
            console.error('Error:', error);
            $('#lineList,#cellList').empty();
        }
    })
}

/**
 * 自定义消息提示框
 * @param message 提示信息
 * @param time 弹窗几秒消失
 * @param params 自定义样式
 */
function myAlert(message, time, params) {
    let width = 260;
    let height = 50;
    let color = "#FFF";
    let backgroundColor = "rgba(6,9,38,0.9)";
    let fontWeight = "normal";
    let opacity = "0.6";
    // console.log(isNaN(Number(time)))
    if (!time || isNaN(Number(time))) {
        //默认值，2.5s
        time = 2500;
    }

    //获取顶级窗口,设置弹窗块级区域
    let bodyEle = window.top.document.body;
    let divELe = document.createElement("div");

    //实现CSS多样化,自定义赋值
    divELe.className = 'myAlert';
    divELe.style.width = width + 'px';
    divELe.style.height = height + 'px';
    divELe.style.position = 'fixed';
    divELe.style.top = '0px';
    divELe.style.left = '50%';
    divELe.style.marginLeft = -width / 2 + 'px';
    divELe.style.marginTop = '10px';
    divELe.style.color = color;
    divELe.style.backgroundColor = backgroundColor;
    divELe.style.textAlign = "center";
    divELe.style.lineHeight = height + "px";
    divELe.style.fontSize = "15px";
    divELe.style.border = "0px";
    divELe.style.borderRadius = "5px";
    divELe.style.opacity = opacity;
    divELe.style.fontWeight = fontWeight;
    divELe.style.display = "none";

    //设置给定参数,实现CSS多样化,自定义赋值
    if (params && params instanceof Object) {
        for (let item in params) {
            divELe.style[item] = params[item];
            if (item == 'width') {
                let width = params[item].substring(0, params[item].length - 2)
                divELe.style.marginLeft = -width / 2 + 'px';
            }
            if (item === 'height') {
                divELe.style.lineHeight = params[item];
            }
        }
    }
    divELe.innerText = message;
    bodyEle.appendChild(divELe);
    $(".myAlert").slideDown(200, () => {
        setTimeout(() => {
            $(".myAlert").slideUp(200, () => {
                $(".myAlert").remove();
            })
        }, time)

    });
}

// 成功
function successAlert(message, time) {
    myAlert(message, time, {color: '#00FF00'})
}

// 失败
function errorAlert(message, time) {
    myAlert(message, time, {backgroundColor: '#FF0000', fontWeight: 'bold', color: '#000', opacity: '1'})
}

// 警告
function warningAlert(message, time) {
    myAlert(message, time, {color: '#FFA500'})
}

window.onbeforeunload = onUnload;

function onUnload() {
    if (xhr) xhr.abort();
    console.log("xhr>>>>>>>" + xhr);
    // return "some message";
}


